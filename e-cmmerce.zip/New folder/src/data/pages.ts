export interface InfoSection {
  heading: string
  body: string[]
  bullets?: string[]
}

export interface InfoPage {
  slug: string
  title: string
  category: string
  lede: string
  updated: string
  sections: InfoSection[]
  related: string[]
}

export const infoPages: InfoPage[] = [
  {
    slug: 'about',
    title: 'About Nexa',
    category: 'Company',
    lede: 'Nexa is a working storefront demo: a real catalogue, a real cart, a real checkout flow — and an AI assistant that can talk about anything.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'What this site is',
        body: [
          'Nexa is a demonstration marketplace built to show how a large retail storefront fits together end to end. Everything you can click works: searching, filtering, sorting, product pages, the cart, the checkout form and order history.',
          'It is not a real retailer. No payment is taken, no order ships, and there is no warehouse behind the delivery dates you see.',
        ],
        bullets: [
          '194 products across 24 categories, with real product photography',
          'Cart, saved lists and order history stored in your own browser',
          'A general-purpose AI assistant, Nexa Assist, available on every page',
        ],
      },
      {
        heading: 'How the catalogue is put together',
        body: [
          'The catalogue is generated at build time from open sample product data, then enriched with deterministic fields so the site behaves consistently: prices, list prices, ratings, review counts, stock levels, sellers and delivery windows.',
          'Because the enrichment is seeded from each product title, the same product always shows the same rating and delivery estimate. Reload the page as often as you like — nothing shuffles underneath you.',
        ],
      },
      {
        heading: 'Where your data lives',
        body: [
          'There is no account system and no server-side profile. Your cart, saved items, recently viewed products, delivery postcode and order history are written to your browser\'s local storage and never leave the device.',
          'Clearing site data resets the store to a clean state. The assistant is the only feature that talks to an outside service, and only when you send it a message.',
        ],
      },
    ],
    related: ['science', 'devices', 'help'],
  },
  {
    slug: 'careers',
    title: 'Careers at Nexa',
    category: 'Company',
    lede: 'How a storefront team of this shape is organised, and what the work actually involves.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'A note before you apply',
        body: [
          'Nexa is a demo storefront. There are no live vacancies and no application form on this site — this page describes how the team behind a store like this is typically structured, so you can see where the work sits.',
        ],
      },
      {
        heading: 'The teams',
        body: [
          'A marketplace of this shape splits into a handful of durable teams. Each owns a slice of the customer journey and the metrics that go with it.',
        ],
        bullets: [
          'Catalogue — product data quality, enrichment, search relevance and category structure',
          'Storefront — the pages you browse: home, search, product detail, navigation',
          'Checkout — cart, pricing, tax, payment integration and order placement',
          'Fulfilment — delivery estimates, stock visibility and post-purchase tracking',
          'Platform — infrastructure, performance budgets, accessibility and observability',
        ],
      },
      {
        heading: 'What the work looks like',
        body: [
          'Storefront work is measured in milliseconds and conversion. A change to the search results layout is judged on whether people find what they want faster, not on how it looks in a screenshot.',
          'Engineering roles here tend to be full-stack and product-facing: you own a feature from the data model through to the interface, and you are expected to measure the result rather than hand it off.',
        ],
      },
      {
        heading: 'Hiring in practice',
        body: [
          'Typical loops run four stages: a conversation about your past work, a practical exercise using real constraints, a systems or product discussion with the team you would join, and a final conversation about scope and expectations.',
          'We do not use trick questions or timed puzzle rounds. The exercise is close to the work you would actually do in your first month.',
        ],
      },
    ],
    related: ['about', 'blog', 'help'],
  },
  {
    slug: 'blog',
    title: 'The Nexa Blog',
    category: 'Company',
    lede: 'Notes on building a storefront: search relevance, pricing display, performance and the awkward edges of commerce.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'What we write about',
        body: [
          'The blog is where the storefront team writes down what it learned. Posts are practical: a change we made, why we made it, and what happened to the numbers afterwards.',
        ],
        bullets: [
          'Search relevance — why exact-match ranking beats popularity for long queries',
          'Pricing display — what showing a struck-through list price does to trust',
          'Performance — keeping a 194-item catalogue fast without a loading spinner',
          'Accessibility — labelling star ratings so screen readers do not read five identical characters',
        ],
      },
      {
        heading: 'Recent posts',
        body: [
          'Building this catalogue: turning open product data into a coherent storefront — how prices, ratings and stock are seeded so the same product behaves the same way every visit.',
          'Streaming an assistant into a storefront: why the chat replies token by token instead of waiting for a complete answer, and how to keep the API key on the server where it belongs.',
          'The cart that survives a reload: a small state layer over browser storage, and the edge cases that bite when you trust local data.',
        ],
      },
      {
        heading: 'Contributing',
        body: [
          'Posts are written by the people who shipped the change. If you work on the storefront, you are expected to write up anything that changed a number — including the changes that did not work.',
        ],
      },
    ],
    related: ['about', 'science', 'devices'],
  },
  {
    slug: 'investors',
    title: 'Investor Relations',
    category: 'Company',
    lede: 'How a marketplace like this makes money, where the costs sit, and what the unit economics look like.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'A demo, not a listed company',
        body: [
          'Nexa has no shares, no filings and no investor materials. What follows is a plain-language explanation of the business model a store of this shape runs on, which is more useful than a fake share price.',
        ],
      },
      {
        heading: 'Where the revenue comes from',
        body: [
          'Retail margin is thin and predictable. Marketplaces make their real money from the services wrapped around the sale.',
        ],
        bullets: [
          'First-party retail — buy at wholesale, sell at retail, keep the spread',
          'Third-party commission — a percentage of every sale fulfilled by another seller',
          'Advertising — sponsored placements in search results and on product pages',
          'Subscriptions — delivery membership billed monthly or annually',
          'Cloud and logistics — selling the infrastructure a marketplace already built',
        ],
      },
      {
        heading: 'Where the costs sit',
        body: [
          'Fulfilment dominates: storage, picking, packing and the last mile. Technology is cheaper than most people assume; customer returns and delivery failures are more expensive than most people assume.',
          'The single biggest lever in a marketplace is not price. It is whether the item someone wanted was in stock, findable, and arrived when the page promised.',
        ],
      },
      {
        heading: 'What we would report',
        body: [
          'For a business like this, the figures that matter are revenue mix between first- and third-party, advertising revenue as a share of operating income, delivery cost per parcel, and repeat purchase rate on a twelve-month basis.',
        ],
      },
    ],
    related: ['about', 'advertise', 'sell'],
  },
  {
    slug: 'devices',
    title: 'Nexa Devices',
    category: 'Company',
    lede: 'The hardware a storefront like this would build, and why a retailer bothers making devices at all.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'Why a store would build hardware',
        body: [
          'Retailers build devices for one reason: the device is the front door to the shop. A speaker that can reorder groceries, a display that shows delivery status, a reader that turns a page into a purchase — each one shortens the distance between wanting something and having it.',
          'None of the devices described here exist. They describe the categories a store of this shape would build.',
        ],
      },
      {
        heading: 'The line-up',
        body: [
          'Four categories cover most of the ground a storefront wants to own in the home.',
        ],
        bullets: [
          'Nexa Hub — a small smart display for delivery tracking, lists and voice ordering',
          'Nexa Echo — a speaker built around reordering staples you buy on a schedule',
          'Nexa Reader — an e-ink tablet tied to the store\'s book catalogue',
          'Nexa Home — a hub that talks to lights, locks and thermostats',
        ],
      },
      {
        heading: 'The hard part',
        body: [
          'The hardware is the easy half. The difficult half is deciding what the device says and when: an assistant that interrupts you to suggest a purchase is a device people unplug.',
          'The design rule we would hold to is that a store device should be quiet by default, useful without buying anything, and never the only way to reach a feature.',
        ],
      },
    ],
    related: ['science', 'about', 'blog'],
  },
  {
    slug: 'science',
    title: 'Nexa Science',
    category: 'Company',
    lede: 'The research problems a storefront actually has: ranking, forecasting, and knowing when a model is confidently wrong.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'Ranking is the product',
        body: [
          'On a page with 194 products, ranking is a convenience. On a page with two hundred million, ranking is the entire experience — the difference between a shop that feels curated and one that feels broken.',
          'The useful signal is rarely popularity alone. A query for a specific model number wants the exact match, even if a cheaper generic item sells a hundred times more. Blending intent classification with behavioural signals is where most of the gain comes from.',
        ],
      },
      {
        heading: 'Forecasting demand',
        body: [
          'Deciding where to put stock is a time-series problem with brutal consequences for being wrong: too little and you lose the sale, too much and you pay to store it.',
          'The interesting part is not the point forecast but the interval around it. A model that says "we will sell between four and forty" is more honest, and more useful for a buying decision, than one that says "eleven".',
        ],
      },
      {
        heading: 'Knowing when to say nothing',
        body: [
          'Assistants fail in a specific and costly way: they answer with the same confidence whether they are right or guessing. A shopping assistant that invents a specification is worse than no assistant.',
          'Our approach is to ground answers in the catalogue where possible, refuse where the data is absent, and never present a generated number as a quoted price.',
        ],
      },
    ],
    related: ['devices', 'about', 'blog'],
  },
  {
    slug: 'sell',
    title: 'Sell on Nexa',
    category: 'Sell',
    lede: 'What it takes to list products on a marketplace: fees, fulfilment options, and the requirements that actually get sellers rejected.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'How selling works',
        body: [
          'You list a product, set a price, and choose who ships it. The marketplace charges a referral fee on each sale, plus a fulfilment fee if it stores and ships the item for you.',
          'Referral fees vary by category — electronics sit at the low end, apparel and jewellery at the high end — because the costs of returns and customer service vary the same way.',
        ],
      },
      {
        heading: 'Two fulfilment routes',
        body: [
          'Fulfilled by Nexa means you send stock to a hub; we store, pick, pack and ship it, and your listings carry the fast-delivery badge. Fulfilled by you means you ship from your own warehouse and keep more of the margin, but you carry the delivery promise.',
        ],
        bullets: [
          'Fulfilled by Nexa — best for small, high-volume items and anything with a tight delivery promise',
          'Fulfilled by you — best for fragile, oversized or made-to-order goods',
          'Hybrid — send your best sellers to a hub and ship the long tail yourself',
        ],
      },
      {
        heading: 'What gets listings rejected',
        body: [
          'Most rejections are not about the product. They are about the listing: missing images, vague titles, incorrect dimensions, or a price that does not match the unit being sold.',
        ],
        bullets: [
          'Images on a plain background, at least 1000 pixels on the long edge',
          'A title that names the product, brand and size — no promotional text',
          'Accurate weight and dimensions, because delivery promises depend on them',
          'A price that matches what the customer receives, including the quantity',
        ],
      },
      {
        heading: 'This is a demo',
        body: [
          'There is no seller onboarding on this site. The seller names on product pages are generated sample data so the storefront has something realistic to display.',
        ],
      },
    ],
    related: ['advertise', 'shipping', 'host-a-hub'],
  },
  {
    slug: 'affiliate',
    title: 'Become an Affiliate',
    category: 'Sell',
    lede: 'Earning a commission by linking to products — how tracking works, what pays, and what does not.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'How affiliate links work',
        body: [
          'You place a tracked link to a product on your site, in a video description or in a newsletter. If someone clicks it and buys within a short window, you earn a percentage of the order.',
          'Tracking is done with a tag appended to the URL. The tag survives the click, is stored against the session, and attributes the purchase even if the buyer browses a few more pages first.',
        ],
      },
      {
        heading: 'What earns commission',
        body: [
          'Commission is paid on the item price, not on tax or delivery, and not on gift wrapping. Rates differ by category and are published per category rather than negotiated.',
        ],
        bullets: [
          'Qualifying purchases within the attribution window',
          'Any additional items bought in the same session',
          'Digital products and subscriptions, usually at a lower rate',
        ],
      },
      {
        heading: 'What does not',
        body: [
          'Returns, cancelled orders and purchases made after the attribution window are excluded. Buying through your own links is prohibited and ends the account.',
          'Payments are made on a fixed schedule once a balance clears a minimum threshold. Links must disclose the commercial relationship — that is a legal requirement in most places, not a preference.',
        ],
      },
    ],
    related: ['sell', 'advertise', 'terms'],
  },
  {
    slug: 'advertise',
    title: 'Advertise Your Products',
    category: 'Sell',
    lede: 'Sponsored placements: where they appear, how they are priced, and why an irrelevant click costs you money.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'Where ads appear',
        body: [
          'Sponsored products appear inside search results and in dedicated placements on product pages. They are always labelled, on this site as well as on real ones — a placement that pretends to be organic is a placement that erodes trust in every other result on the page.',
        ],
        bullets: [
          'Search results, interleaved with organic results',
          'Product detail pages, in the "similar items" region',
          'Category and department landing pages',
        ],
      },
      {
        heading: 'How you pay',
        body: [
          'Most marketplace advertising is cost-per-click with a bid you set, not a flat fee. You choose a bid per click and a daily budget; the auction decides whether your ad shows and where.',
          'The trap is relevance. A high bid on a broad keyword buys you clicks from people who will not buy, and you pay for every one. Narrow targeting with a lower bid usually beats broad targeting with a high one.',
        ],
      },
      {
        heading: 'Measuring it honestly',
        body: [
          'Cost-per-click only tells you what you spent. The number that matters is incremental sales — what you sold because of the ad, above what you would have sold anyway.',
          'The reliable measurement is a holdout: run the campaign in some categories and not others, or pause and restart on a schedule, and compare. Attribution alone will always overstate the ad\'s contribution because it counts sales that were already going to happen.',
        ],
      },
    ],
    related: ['sell', 'affiliate', 'investors'],
  },
  {
    slug: 'self-publish',
    title: 'Independent Publishing',
    category: 'Sell',
    lede: 'Publishing a book, audiobook or comic without a traditional publisher: royalties, formatting and the parts people underestimate.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'What independent publishing means',
        body: [
          'You keep the rights, you control the price, and you earn a royalty per copy sold instead of an advance. The trade is that you also own the editing, the cover, the formatting and the marketing.',
          'Royalty rates depend on format and price band: ebooks pay the highest percentage in a mid-price window, print pays less because the physical book has to be manufactured, and audiobooks sit in between.',
        ],
      },
      {
        heading: 'The parts people underestimate',
        body: [
          'Writing the book is the part authors plan for. The rest is what delays release by months.',
        ],
        bullets: [
          'Editing — developmental, then line, then proof. Three passes, not one',
          'Cover design — the single largest factor in whether someone clicks',
          'Formatting — ebooks need clean markup; print needs bleed, margins and trim size',
          'Metadata — title, subtitle, keywords and categories decide whether the book is findable at all',
        ],
      },
      {
        heading: 'Pricing',
        body: [
          'Price is a lever, not a statement of quality. A first book in a series is often priced low deliberately to bring readers in, with later books at full price.',
          'Changing the price is the fastest experiment available: adjust it, wait for a full sales cycle, and compare units sold rather than revenue alone.',
        ],
      },
    ],
    related: ['sell', 'advertise', 'affiliate'],
  },
  {
    slug: 'host-a-hub',
    title: 'Host a Nexa Hub',
    category: 'Sell',
    lede: 'Running a small delivery hub in your own community: what the space needs, what the work pays, and what a typical day looks like.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'What a hub is',
        body: [
          'A hub is a small local facility where parcels are sorted for the last mile. Instead of every van driving from a central warehouse, packages arrive in bulk overnight and go out from a building close to the customer.',
          'Hubs are typically run by independent operators under contract, using a standard layout provided by the network.',
        ],
      },
      {
        heading: 'What the space needs',
        body: [
          'A workable hub is modest — a few hundred square metres — but the specifics matter more than the size.',
        ],
        bullets: [
          'Drive-in access for a rigid lorry, with a turning circle that actually fits',
          'Level flooring and a covered loading bay, because sorting happens in all weather',
          'Power for charging racks and a small office area',
          'A location within a short drive of the delivery routes it serves',
        ],
      },
      {
        heading: 'The working day',
        body: [
          'The pattern is early and compressed. Bulk deliveries land before dawn, parcels are scanned and sorted by route, drivers collect, and the building is largely quiet by mid-morning. The afternoon is returns, exceptions and preparing for the next inbound.',
          'The skill is not physical speed. It is accuracy under time pressure: a parcel sorted to the wrong route costs more than one sorted slowly.',
        ],
      },
    ],
    related: ['sell', 'shipping', 'careers'],
  },
  {
    slug: 'business-card',
    title: 'Nexa Business Card',
    category: 'Payments',
    lede: 'A charge card aimed at small businesses: how the limits work, what the rewards cover, and where the fees are.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'How it works',
        body: [
          'The card is a charge card rather than a credit card: the balance is due in full each month, and in exchange there is no preset spending limit — approval is based on your account history and typical spend.',
          'It is designed for businesses buying stock, supplies and equipment, where the purchase is paid off as the goods sell rather than carried as debt.',
        ],
      },
      {
        heading: 'Rewards',
        body: [
          'Rewards are paid as a percentage back on purchases, weighted toward business categories — office supplies, computing and shipping — with a lower rate on everything else.',
        ],
        bullets: [
          'Higher rate on business categories, lower flat rate elsewhere',
          'No annual fee on the basic tier',
          'Rewards usable against purchases, not paid out as cash',
        ],
      },
      {
        heading: 'Where the costs are',
        body: [
          'There is no annual fee on the standard card, but there are real costs if you use it in the wrong currency or carry a balance. Foreign transactions typically carry a percentage fee, and a charge card that is not paid in full attracts interest at a high rate.',
          'This page describes a product that does not exist on this demo site. No card is issued, and no application is collected.',
        ],
      },
    ],
    related: ['points', 'reload-balance', 'terms'],
  },
  {
    slug: 'points',
    title: 'Shop with Points',
    category: 'Payments',
    lede: 'Spending reward points at checkout: what a point is worth, where you can use them, and why the value varies.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'What points are worth',
        body: [
          'A reward point is worth a fixed amount when redeemed against an eligible purchase, usually a cent or slightly less. On a $20 item, 2000 points at one cent each covers the whole thing.',
          'The value varies by scheme. Some partners redeem at a flat rate across all purchases; others only allow points on specific categories, or apply a worse rate outside them.',
        ],
      },
      {
        heading: 'Using points at checkout',
        body: [
          'At checkout you choose how much of the balance to apply. Partial redemption is normal — use points for part of the order and pay the rest with a card.',
        ],
        bullets: [
          'Points usually cannot cover tax or delivery in full',
          'Some categories are excluded: gift cards, digital subscriptions and third-party marketplace items',
          'Points applied to an order that is later returned are usually refunded as points, not cash',
        ],
      },
      {
        heading: 'Getting the best value',
        body: [
          'The best value per point is almost always a straightforward purchase redemption, not a transfer to another programme. Transfers look generous because the headline rate is higher, but the redemption value on the other side is usually worse.',
          'Points that expire are worth nothing. Check the expiry policy before saving a balance for a large purchase months away.',
        ],
      },
    ],
    related: ['business-card', 'reload-balance', 'help'],
  },
  {
    slug: 'reload-balance',
    title: 'Reload Your Balance',
    category: 'Payments',
    lede: 'Keeping credit on your account: automatic top-ups, why they are useful, and how to stop one.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'What a balance is for',
        body: [
          'A store balance is credit held against your account that can be spent at checkout before a card is charged. It exists mainly to make repeated small purchases faster and to avoid re-entering payment details.',
          'Balances commonly come from gift cards, refunds and promotional credit. They are not a bank account and they do not earn interest.',
        ],
      },
      {
        heading: 'Automatic top-up',
        body: [
          'Reload lets you set a trigger: when the balance falls below an amount, a fixed sum is charged to a saved card. It is designed for people who buy from the same store often and do not want a decline at checkout.',
        ],
        bullets: [
          'Choose a trigger amount and a reload amount independently',
          'Choose a threshold gap larger than a typical order, or you will reload constantly',
          'You can pause or cancel at any time; pausing does not remove the stored balance',
        ],
      },
      {
        heading: 'Things to know',
        body: [
          'Refunds on an order paid partly with balance go back to the balance first, then to the card. Promotional credit is usually spent before credit you paid for, and often expires sooner.',
          'On this demo, no balance exists and no card is ever charged. The pricing figures are stored locally in your browser if you edit them.',
        ],
      },
    ],
    related: ['points', 'business-card', 'help'],
  },
  {
    slug: 'currency',
    title: 'Currency Converter',
    category: 'Payments',
    lede: 'How prices convert to your currency, why the number you see is an estimate, and what changes it.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'Why prices differ by currency',
        body: [
          'A listed price is set in the seller\'s currency. When you browse in another currency, the storefront converts it for display using a daily reference rate, then rounds to a customer-friendly number.',
          'The converted price is an estimate, not a quote. The rate that applies is the one at the moment the order is placed, and card issuers apply their own spread on top.',
        ],
      },
      {
        heading: 'What moves the number',
        body: [
          'Three things change a converted price, and only one of them is the exchange rate.',
        ],
        bullets: [
          'The reference rate — updated daily, not live',
          'The issuer spread — typically one to three percent, added by your bank',
          'Import duties and tax — applied by destination, not by the store',
        ],
      },
      {
        heading: 'Getting a closer estimate',
        body: [
          'For a realistic figure, take the listed price in its original currency, convert at a rate you can look up, and add two to three percent plus your country\'s tax on the category.',
          'This demo stores prices in US dollars and does not perform live conversion. The checkout shows the same figures you see on the product page.',
        ],
      },
    ],
    related: ['shipping', 'returns', 'points'],
  },
  {
    slug: 'shipping',
    title: 'Shipping Rates & Policies',
    category: 'Help',
    lede: 'What delivery actually costs, how estimates are calculated, and what happens when a parcel is late.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'What you pay',
        body: [
          'Standard delivery in this demo is free on orders over $35; below that a flat $4.99 applies. That threshold is a pricing lever as much as a delivery policy — it nudges small orders upward without discounting the goods.',
        ],
        bullets: [
          'Orders over $35 — free standard delivery',
          'Orders under $35 — $4.99 flat',
          'Delivery estimates are counted in business days from dispatch, not from order',
        ],
      },
      {
        heading: 'How the estimate is calculated',
        body: [
          'A delivery promise is built from three pieces: handling time at the hub, transit time between hubs, and the last-mile route to your postcode. The slowest of the three, not the average, is what the page has to promise.',
          'That is why the same product can show different dates for two postcodes. It is also why a promise that is consistently beaten is a sign the estimate is padded rather than accurate.',
        ],
      },
      {
        heading: 'When it is late',
        body: [
          'If a parcel misses its promised date, the useful next step is the tracking record, not the order page. A scan that has not moved in forty-eight hours means a physical problem; no scan at all usually means the label was never collected.',
          'Late delivery is refundable on the delivery charge, not on the item. If the item never arrives, that is a lost-parcel claim and is refunded in full.',
        ],
      },
      {
        heading: 'Demo note',
        body: [
          'Nothing here ships. The delivery windows on product pages are generated from the catalogue and are consistent per product so the storefront feels real.',
        ],
      },
    ],
    related: ['returns', 'host-a-hub', 'help'],
  },
  {
    slug: 'returns',
    title: 'Returns & Replacements',
    category: 'Help',
    lede: 'The returns window, which items are excluded, and the difference between a refund and a replacement.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'The window',
        body: [
          'Most items can be returned within 30 days of delivery, in a resalable condition. The window starts on the delivery date, not the order date — a distinction that matters for anything shipped slowly.',
          'Some categories run shorter windows because the product has a shelf life or cannot be resold: groceries, opened cosmetics, and personalised items.',
        ],
      },
      {
        heading: 'Refund or replacement',
        body: [
          'A refund returns your money. A replacement sends the same item again. Choose a replacement when the item is wrong or faulty and you still want it; choose a refund when you no longer do.',
          'Faulty items are not subject to the change-of-mind rules — a defective product is replaced or refunded regardless of window, and the return postage is covered.',
        ],
        bullets: [
          'Changed your mind — 30 days, item must be resalable, return postage may apply',
          'Wrong item sent — replaced or refunded, postage covered',
          'Faulty on arrival — replaced or refunded, postage covered, no window',
          'Damaged in transit — report within 48 hours with photographs',
        ],
      },
      {
        heading: 'How the money comes back',
        body: [
          'Refunds go to the original payment method. Anything paid with store balance returns to balance first, which is usually immediate, then the card, which takes three to five business days.',
          'This is a demo storefront: there is no returns process behind it. Order history is stored in your browser only.',
        ],
      },
    ],
    related: ['shipping', 'help', 'terms'],
  },
  {
    slug: 'help',
    title: 'Help & Customer Service',
    category: 'Help',
    lede: 'Where to look for each kind of problem, and the fastest route to a real answer.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'Start with the right page',
        body: [
          'Most questions have a written answer that is faster than waiting for a reply. These are the four that cover the majority of contacts.',
        ],
        bullets: [
          'Order status and history — Your Orders',
          'Delivery timing and costs — Shipping Rates & Policies',
          'Sending something back — Returns & Replacements',
          'Account data stored on this device — Your Account',
        ],
      },
      {
        heading: 'Ask the assistant',
        body: [
          'Nexa Assist sits in the corner of every page and can answer most questions about the catalogue, compare two products, or explain a policy. It also knows what is in your cart and which product you are looking at.',
          'It is a general assistant, so it will also happily discuss cooking, travel or code — but for anything about a specific order, the written policy pages are the authoritative source.',
        ],
      },
      {
        heading: 'When something is actually broken',
        body: [
          'If a page will not load, the cart empties itself, or a price looks wrong, the fastest fix is usually to clear this site\'s stored data and reload — the store keeps its state in your browser, and a corrupted entry survives refreshes.',
          'To report a fault, include the page address, what you clicked, and what you expected to happen. A screenshot of the browser console is worth more than a description of the symptom.',
        ],
      },
    ],
    related: ['returns', 'shipping', 'account'],
  },
  {
    slug: 'account',
    title: 'Your Account',
    category: 'Help',
    lede: 'There is no login here. This is exactly what the store remembers about you, and where it lives.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'No account, no password',
        body: [
          'Nexa has no sign-in. Everything the storefront remembers is stored in your browser\'s local storage under a handful of keys, and it never reaches a server.',
          'That means there is nothing to hack and nothing to log out of — but also nothing that follows you to another device or survives clearing site data.',
        ],
        bullets: [
          'Cart contents and quantities',
          'Saved list and recently viewed products',
          'Order history placed in this browser',
          'Delivery postcode',
        ],
      },
      {
        heading: 'Clearing it',
        body: [
          'Clearing site data for this address resets the store to a fresh state: empty cart, no orders, default postcode. There is no undo, because there is no copy anywhere else.',
          'If you only want to remove one thing, remove it from the interface — delete a cart line, unsave an item, or empty the cart from the cart page.',
        ],
      },
      {
        heading: 'What we do not store',
        body: [
          'No payment details are collected at checkout, no email address is retained after an order, and no analytics profile is built. The assistant sends your message and recent conversation to a model provider to generate a reply, and that is the only outbound request the app makes on your behalf.',
        ],
      },
    ],
    related: ['help', 'privacy', 'returns'],
  },
  {
    slug: 'privacy',
    title: 'Privacy Notice',
    category: 'Legal',
    lede: 'What this demo collects, what it does not, and the only outbound request it makes.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'What is collected',
        body: [
          'This storefront collects nothing about you. There is no analytics script, no tracking pixel, no advertising identifier and no account system.',
          'Cart, saved items, recently viewed products, postcode and order history are written to your browser\'s local storage. That data stays on your device and is readable by anyone with access to it — treat it as you would any local file.',
        ],
      },
      {
        heading: 'The one exception: the assistant',
        body: [
          'When you send a message to Nexa Assist, the text of that message and recent turns of the conversation are sent to a language model provider to generate a reply. The request also includes a short description of the page you are on, your cart total and the product you are viewing, so the answer can be relevant.',
          'Your API key is held on the server and is never sent to the browser. Messages are not stored by this app after the page is reloaded — the conversation lives in memory only.',
        ],
      },
      {
        heading: 'Third parties',
        body: [
          'Product photography is loaded from a public image CDN, which will see your IP address and the image requested. Fonts are system fonts, so nothing is fetched from a font service.',
          'There are no cookies set by this application.',
        ],
      },
      {
        heading: 'Your controls',
        body: [
          'Clearing site data for this address removes everything stored locally. Because nothing is stored server-side, there is no profile to request or delete.',
        ],
      },
    ],
    related: ['terms', 'ad-choices', 'account'],
  },
  {
    slug: 'terms',
    title: 'Conditions of Use',
    category: 'Legal',
    lede: 'The terms you are agreeing to when you use this demo storefront.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'What this site is',
        body: [
          'Nexa is a demonstration storefront provided for evaluation and learning. There is no retailer behind it, no warehouse, no payment processor and no customer service team.',
          'By using the site you accept that nothing here constitutes a real offer for sale, and that no order placed creates a contract for goods or services.',
        ],
      },
      {
        heading: 'Orders and payments',
        body: [
          'The checkout form collects a name, address and email for the purpose of rendering a confirmation page. Those values are stored only in your own browser. No payment method is requested, no card is charged and nothing is dispatched.',
        ],
      },
      {
        heading: 'Catalogue and pricing',
        body: [
          'Product names, photography and descriptions come from open sample data. Prices, ratings, review counts, stock levels, seller names and delivery estimates are generated for demonstration and must not be relied on as accurate.',
        ],
      },
      {
        heading: 'Liability and changes',
        body: [
          'The site is provided as-is, without warranty of any kind. It may change or be taken offline at any time. To the extent permitted by law, no liability is accepted for any loss arising from use of the demonstration.',
        ],
      },
    ],
    related: ['privacy', 'about', 'returns'],
  },
  {
    slug: 'ad-choices',
    title: 'Your Ads Privacy Choices',
    category: 'Legal',
    lede: 'Advertising on this storefront: there is none, and here is what that means in practice.',
    updated: '2026-11-15',
    sections: [
      {
        heading: 'No targeted advertising',
        body: [
          'This storefront serves no advertisements and sets no advertising cookies. It does not build a profile of your browsing, does not share identifiers with ad networks, and does not participate in cross-site tracking.',
          'There is therefore nothing to opt out of on this site. The controls below describe what would normally exist, so you can recognise them elsewhere.',
        ],
      },
      {
        heading: 'What the usual controls mean',
        body: [
          'On commercial sites you will typically see three separate things, often conflated into one toggle.',
        ],
        bullets: [
          'Personalised ads — profiling your behaviour to choose which ads you see',
          'Sale or sharing of data — disclosing identifiers to third parties, which some laws treat as a sale even without money changing hands',
          'Ad measurement — reporting whether an ad was seen or clicked, usually without identifying you',
        ],
      },
      {
        heading: 'How to check any site',
        body: [
          'Open the browser\'s developer tools, go to the network panel and reload. Third-party requests to domains you do not recognise are the practical signature of tracking. A site that loads only its own assets and its own images is not tracking you, whatever its banner claims.',
        ],
      },
    ],
    related: ['privacy', 'terms', 'about'],
  },
]

export const infoPageBySlug = (slug: string): InfoPage | undefined =>
  infoPages.find((page) => page.slug === slug)
