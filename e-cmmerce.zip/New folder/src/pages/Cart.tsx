import { Link } from 'react-router-dom'
import { PrimeBadge } from '../components/ProductCard'
import { ProductRail } from '../components/ProductRail'
import { products } from '../data/catalogue'
import { useStore } from '../context/StoreContext'
import { currency, deliveryWindow } from '../lib/format'

const FREE_SHIPPING = 35

export function CartPage() {
  const { items, subtotal, count, setQty, removeFromCart, clearCart, toggleWishlist, wishlist } = useStore()

  if (!items.length) {
    return (
      <div className="cart-page">
        <div className="cart-empty">
          <h1>Your Nexa Cart is empty</h1>
          <p>Your cart is waiting to be filled. Check today's deals and keep shopping.</p>
          <Link to="/" className="btn btn-primary">
            Continue shopping
          </Link>
          <div className="cart-empty-aside">
            <h2>Your lists</h2>
            <Link to="/wishlist">View your saved items ({wishlist.length})</Link>
          </div>
        </div>
        <ProductRail
          title="Recommended for you"
          products={[...products].sort((a, b) => b.rating - a.rating).slice(0, 12)}
          seeMoreTo="/search?sort=rating"
        />
      </div>
    )
  }

  const shipping = subtotal >= FREE_SHIPPING ? 0 : 4.99
  const tax = Number((subtotal * 0.0825).toFixed(2))
  const total = Number((subtotal + shipping + tax).toFixed(2))
  const remaining = Math.max(0, FREE_SHIPPING - subtotal)
  const progress = Math.min(100, (subtotal / FREE_SHIPPING) * 100)
  const maxDelivery = Math.max(...items.map((item) => item.product.deliveryDays))

  return (
    <div className="cart-page">
      <div className="cart-main">
        <section className="cart-lines">
          <header className="cart-head">
            <h1>Shopping Cart</h1>
            <span className="cart-head-price">Price</span>
          </header>

          {items.map(({ product, qty, lineTotal }) => {
            const saved = wishlist.includes(product.id)
            return (
              <article key={product.id} className="cart-line">
                <Link to={`/product/${product.id}`} className="cart-line-media">
                  <img src={product.images[0]} alt={product.title} />
                </Link>

                <div className="cart-line-body">
                  <Link to={`/product/${product.id}`} className="cart-line-title">
                    {product.title}
                  </Link>
                  <p className="cart-line-stock">
                    {product.stock < 10 ? (
                      <span className="stock-low">Only {product.stock} left in stock — order soon</span>
                    ) : (
                      <span className="stock-ok">In stock</span>
                    )}
                  </p>
                  {product.prime && <PrimeBadge />}
                  <p className="cart-line-seller">
                    Sold by {product.soldBy} · {product.categoryLabel}
                  </p>

                  <div className="cart-line-actions">
                    <label className="cart-qty">
                      <span className="visually-hidden">Quantity</span>
                      <select value={qty} onChange={(event) => setQty(product.id, Number(event.target.value))}>
                        {Array.from({ length: Math.min(10, Math.max(product.stock, 1)) }, (_, i) => i + 1).map((n) => (
                          <option key={n} value={n}>
                    Qty: {n}
                          </option>
                        ))}
                      </select>
                    </label>
                    <span className="cart-divider" />
                    <button type="button" className="cart-remove" onClick={() => removeFromCart(product.id)}>
                      Delete
                    </button>
                    <span className="cart-divider" />
                    <button
                      type="button"
                      className="cart-save"
                      onClick={() => {
                        toggleWishlist(product.id)
                        removeFromCart(product.id)
                      }}
                    >
                      {saved ? 'Saved to your list' : 'Save for later'}
                    </button>
                  </div>
                </div>

                <div className="cart-line-price">
                  <span className="cart-line-each">{currency(product.price)} each</span>
                  <span className="cart-line-total">{currency(lineTotal)}</span>
                </div>
              </article>
            )
          })}

          <footer className="cart-foot">
            Subtotal ({count} item{count === 1 ? '' : 's'}): <strong>{currency(subtotal)}</strong>
            <button type="button" className="link-like" onClick={clearCart}>
              Empty cart
            </button>
          </footer>
        </section>

        <aside className="cart-summary">
          {remaining > 0 ? (
            <p className="summary-free">
              Add <strong>{currency(remaining)}</strong> of eligible items to get FREE delivery.
            </p>
          ) : (
            <p className="summary-free is-qualified">
              ✓ Your order qualifies for FREE delivery.
            </p>
          )}
          <div className="cart-progress">
            <div style={{ width: `${progress}%` }} />
          </div>

          <div className="summary-row">
            <span>Items ({count})</span>
            <span>{currency(subtotal)}</span>
          </div>
          <div className="summary-row">
            <span>Delivery</span>
            <span>{shipping === 0 ? 'FREE' : currency(shipping)}</span>
          </div>
          <div className="summary-row">
            <span>Estimated tax</span>
            <span>{currency(tax)}</span>
          </div>
          <div className="summary-row summary-total">
            <span>Order total</span>
            <span>{currency(total)}</span>
          </div>

          <Link to="/checkout" className="btn btn-primary btn-block">
            Proceed to checkout
          </Link>
          <p className="summary-eta">Delivery by {deliveryWindow(maxDelivery - 1)}</p>
          <p className="summary-note">Demo storefront — no payment is taken and no order ships.</p>
        </aside>
      </div>
    </div>
  )
}
