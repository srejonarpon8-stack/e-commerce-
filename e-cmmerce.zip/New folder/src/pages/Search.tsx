import { useMemo } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { PrimeBadge } from '../components/ProductCard'
import { RatingLine } from '../components/Stars'
import { categories, departments, products } from '../data/catalogue'
import { useStore } from '../context/StoreContext'
import { currency } from '../lib/format'
import type { Product } from '../types'

const PER_PAGE = 16

const PRICE_BANDS = [
  { key: 'under25', label: 'Under $25', min: 0, max: 25 },
  { key: '25to50', label: '$25 to $50', min: 25, max: 50 },
  { key: '50to100', label: '$50 to $100', min: 50, max: 100 },
  { key: '100to200', label: '$100 to $200', min: 100, max: 200 },
  { key: 'over200', label: '$200 & above', min: 200, max: Infinity },
]

const SORTS = [
  { key: 'featured', label: 'Featured' },
  { key: 'price-asc', label: 'Price: Low to High' },
  { key: 'price-desc', label: 'Price: High to Low' },
  { key: 'rating', label: 'Average Customer Review' },
  { key: 'reviews', label: 'Most Reviewed' },
  { key: 'new', label: 'Newest Arrivals' },
]

export function SearchPage() {
  const [params, setParams] = useSearchParams()
  const { addToCart, wishlist, toggleWishlist } = useStore()

  const query = (params.get('q') || '').trim()
  const deptKey = params.get('dept') || ''
  const catKey = params.get('cat') || ''
  const sortKey = params.get('sort') || 'featured'
  const bandKey = params.get('price') || ''
  const minRating = Number(params.get('rating') || 0)
  const onlyDeals = params.get('deals') === '1'
  const selectedBrands = params.getAll('brand')
  const page = Math.max(1, Number(params.get('page') || 1))

  const scope = useMemo(() => {
    return products.filter((product) => {
      if (deptKey && product.department !== deptKey) return false
      if (catKey && product.category !== catKey) return false
      if (query) {
        const haystack = `${product.title} ${product.brand} ${product.categoryLabel} ${product.description}`.toLowerCase()
        if (!haystack.includes(query.toLowerCase())) return false
      }
      return true
    })
  }, [deptKey, catKey, query])

  const brandFacets = useMemo(() => {
    const counts = new Map<string, number>()
    scope.forEach((product) => counts.set(product.brand, (counts.get(product.brand) || 0) + 1))
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10)
  }, [scope])

  const results = useMemo(() => {
    const band = PRICE_BANDS.find((b) => b.key === bandKey)
    let list: Product[] = scope.filter((product) => {
      if (band && (product.price < band.min || product.price >= band.max)) return false
      if (minRating && product.rating < minRating) return false
      if (onlyDeals && !product.listPrice) return false
      if (selectedBrands.length && !selectedBrands.includes(product.brand)) return false
      return true
    })

    switch (sortKey) {
      case 'price-asc':
        list = [...list].sort((a, b) => a.price - b.price)
        break
      case 'price-desc':
        list = [...list].sort((a, b) => b.price - a.price)
        break
      case 'rating':
        list = [...list].sort((a, b) => b.rating - a.rating)
        break
      case 'reviews':
        list = [...list].sort((a, b) => b.ratingCount - a.ratingCount)
        break
      case 'new':
        list = [...list].sort((a, b) => b.createdAt - a.createdAt)
        break
      default:
        list = [...list].sort(
          (a, b) => Number(b.bestseller) - Number(a.bestseller) || b.rating - a.rating,
        )
    }
    return list
  }, [scope, bandKey, minRating, onlyDeals, selectedBrands, sortKey])

  const totalPages = Math.max(1, Math.ceil(results.length / PER_PAGE))
  const safePage = Math.min(page, totalPages)
  const visible = results.slice((safePage - 1) * PER_PAGE, safePage * PER_PAGE)

  const update = (mutate: (next: URLSearchParams) => void) => {
    const next = new URLSearchParams(params)
    mutate(next)
    next.delete('page')
    setParams(next, { replace: true })
  }

  const dept = departments.find((d) => d.key === deptKey)
  const cat = categories.find((c) => c.slug === catKey)
  const heading = query
    ? `“${query}”`
    : onlyDeals
      ? "Today's Deals"
      : cat?.label || dept?.label || 'All departments'

  return (
    <div className="search-page">
      <div className="search-crumbs">
        <Link to="/">Home</Link>
        <span>/</span>
        {dept ? <Link to={`/search?dept=${dept.key}`}>{dept.label}</Link> : <span>All</span>}
        {cat && (
          <>
            <span>/</span>
            <span>{cat.label}</span>
          </>
        )}
      </div>

      <aside className="filters">
        <div className="filter-block">
          <h3>Department</h3>
          <ul>
            <li>
              <button
                type="button"
                className={!deptKey && !catKey ? 'is-active' : ''}
                onClick={() => update((next) => (next.delete('dept'), next.delete('cat')))}
              >
                All departments
              </button>
            </li>
            {departments.map((item) => (
              <li key={item.key}>
                <button
                  type="button"
                  className={deptKey === item.key ? 'is-active' : ''}
                  onClick={() =>
                    update((next) => {
                      next.delete('cat')
                      next.set('dept', item.key)
                    })
                  }
                >
                  {item.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="filter-block">
          <h3>Price</h3>
          <ul>
            {PRICE_BANDS.map((band) => (
              <li key={band.key}>
                <button
                  type="button"
                  className={bandKey === band.key ? 'is-active' : ''}
                  onClick={() =>
                    update((next) => {
                      if (bandKey === band.key) next.delete('price')
                      else next.set('price', band.key)
                    })
                  }
                >
                  {band.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="filter-block">
          <h3>Customer Review</h3>
          <ul>
            {[4, 3, 2].map((stars) => (
              <li key={stars}>
                <button
                  type="button"
                  className={minRating === stars ? 'is-active' : ''}
                  onClick={() =>
                    update((next) => {
                      if (minRating === stars) next.delete('rating')
                      else next.set('rating', String(stars))
                    })
                  }
                >
                  {'★'.repeat(stars)}
                  {'☆'.repeat(5 - stars)} &amp; up
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="filter-block">
          <h3>Brand</h3>
          <ul>
            {brandFacets.map(([brand, count]) => (
              <li key={brand}>
                <label className="filter-check">
                  <input
                    type="checkbox"
                    checked={selectedBrands.includes(brand)}
                    onChange={() =>
                      update((next) => {
                        next.delete('brand')
                        const nextBrands = selectedBrands.includes(brand)
                          ? selectedBrands.filter((b) => b !== brand)
                          : [...selectedBrands, brand]
                        nextBrands.forEach((value) => next.append('brand', value))
                      })
                    }
                  />
                  <span>{brand}</span>
                  <em>{count}</em>
                </label>
              </li>
            ))}
          </ul>
        </div>

        <div className="filter-block">
          <h3>Deals</h3>
          <ul>
            <li>
              <button
                type="button"
                className={onlyDeals ? 'is-active' : ''}
                onClick={() =>
                  update((next) => {
                    if (onlyDeals) next.delete('deals')
                    else next.set('deals', '1')
                  })
                }
              >
                On sale only
              </button>
            </li>
          </ul>
          {(deptKey || catKey || sortKey !== 'featured' || bandKey || minRating || onlyDeals || selectedBrands.length > 0 || query) && (
            <button type="button" className="filter-reset" onClick={() => setParams(new URLSearchParams())}>
              Clear all filters
            </button>
          )}
        </div>
      </aside>

      <section className="results">
        <div className="results-head">
          <h1>
            {heading}
            <span className="results-count">
              {results.length} result{results.length === 1 ? '' : 's'}
            </span>
          </h1>
          <label className="sort">
            <span>Sort by:</span>
            <select
              value={sortKey}
              onChange={(event) =>
                update((next) => {
                  if (event.target.value === 'featured') next.delete('sort')
                  else next.set('sort', event.target.value)
                })
              }
            >
              {SORTS.map((option) => (
                <option key={option.key} value={option.key}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        {results.length === 0 && (
          <div className="results-empty">
            <h2>No results for {heading}</h2>
            <p>Try checking your spelling, using fewer words or clearing a filter or two.</p>
            <button type="button" className="btn btn-primary" onClick={() => setParams(new URLSearchParams())}>
              Reset search
            </button>
          </div>
        )}

        <ul className="result-list">
          {visible.map((product) => {
            const saved = wishlist.includes(product.id)
            const off = product.listPrice
              ? Math.round(((product.listPrice - product.price) / product.listPrice) * 100)
              : 0
            return (
              <li key={product.id} className="result-row">
                <Link to={`/product/${product.id}`} className="result-media">
                  <img src={product.images[0]} alt={product.title} loading="lazy" />
                </Link>
                <div className="result-body">
                  <Link to={`/product/${product.id}`} className="result-title">
                    {product.title}
                  </Link>
                  <div className="result-meta">
                    <RatingLine rating={product.rating} count={product.ratingCount} />
                    {product.bestseller && <span className="badge-bestseller">Best Seller</span>}
                  </div>
                  <p className="result-desc">{product.description}</p>
                  <div className="result-price">
                    <span className="price">
                      <span className="price-symbol">$</span>
                      <span className="price-whole">{product.price.toFixed(2).split('.')[0]}</span>
                      <span className="price-fraction">{product.price.toFixed(2).split('.')[1]}</span>
                    </span>
                    {product.listPrice && (
                      <span className="price-list">
                        <s>{currency(product.listPrice)}</s> -{off}%
                      </span>
                    )}
                  </div>
                  {product.prime && <PrimeBadge />}
                  <p className="result-delivery">
                    FREE delivery <strong>in {product.deliveryDays} days</strong> · {product.soldBy}
                  </p>
                </div>
                <div className="result-buy">
                  <button type="button" className="btn btn-cart" onClick={() => addToCart(product.id)}>
                    Add to cart
                  </button>
                  <button
                    type="button"
                    className="btn btn-ghost btn-block"
                    onClick={() => toggleWishlist(product.id)}
                  >
                    {saved ? '♥ Saved' : '♡ Save'}
                  </button>
                </div>
              </li>
            )
          })}
        </ul>

        {totalPages > 1 && (
          <nav className="pager" aria-label="Pagination">
            <button
              type="button"
              disabled={safePage === 1}
              onClick={() => update((next) => next.set('page', String(safePage - 1)))}
            >
              ‹ Previous
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1)
              .filter((n) => n === 1 || n === totalPages || Math.abs(n - safePage) <= 1)
              .map((n, index, arr) => (
                <span key={n} className="pager-slot">
                  {index > 0 && arr[index - 1] !== n - 1 && <span className="pager-gap">…</span>}
                  <button
                    type="button"
                    className={n === safePage ? 'is-current' : ''}
                    onClick={() => update((next) => next.set('page', String(n)))}
                  >
                    {n}
                  </button>
                </span>
              ))}
            <button
              type="button"
              disabled={safePage === totalPages}
              onClick={() => update((next) => next.set('page', String(safePage + 1)))}
            >
              Next ›
            </button>
          </nav>
        )}
      </section>
    </div>
  )
}
