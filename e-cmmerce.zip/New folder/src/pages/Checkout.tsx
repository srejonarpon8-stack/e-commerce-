import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useStore } from '../context/StoreContext'
import { currency } from '../lib/format'
import type { ShippingAddress } from '../types'

const EMPTY_ADDRESS: ShippingAddress = {
  name: '',
  line1: '',
  city: '',
  postcode: '',
  country: 'United States',
  email: '',
}

export function CheckoutPage() {
  const navigate = useNavigate()
  const { items, subtotal, count, placeOrder, postcode } = useStore()
  const [address, setAddress] = useState<ShippingAddress>({ ...EMPTY_ADDRESS, postcode })
  const [payment, setPayment] = useState('card')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [placing, setPlacing] = useState(false)

  if (!items.length) {
    return (
      <div className="page-narrow">
        <h1>Your cart is empty</h1>
        <p>Add something to your cart before checking out.</p>
        <Link to="/" className="btn btn-primary">
          Continue shopping
        </Link>
      </div>
    )
  }

  const shipping = subtotal >= 35 ? 0 : 4.99
  const tax = Number((subtotal * 0.0825).toFixed(2))
  const total = Number((subtotal + shipping + tax).toFixed(2))

  const set = (key: keyof ShippingAddress, value: string) =>
    setAddress((current) => ({ ...current, [key]: value }))

  const validate = () => {
    const next: Record<string, string> = {}
    if (address.name.trim().length < 3) next.name = 'Enter the full name for delivery'
    if (address.line1.trim().length < 5) next.line1 = 'Enter a street address'
    if (address.city.trim().length < 2) next.city = 'Enter a city'
    if (!/^[a-z0-9][a-z0-9\s-]{2,9}$/i.test(address.postcode.trim())) next.postcode = 'Enter a valid postcode'
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(address.email.trim())) next.email = 'Enter a valid email for the receipt'
    setErrors(next)
    return Object.keys(next).length === 0
  }

  const submit = (event: React.FormEvent) => {
    event.preventDefault()
    if (!validate()) return
    setPlacing(true)
    window.setTimeout(() => {
      placeOrder(address)
      navigate('/orders?placed=1')
    }, 650)
  }

  return (
    <div className="checkout">
      <ol className="checkout-steps">
        <li className="is-done">1. Cart</li>
        <li className="is-current">2. Delivery &amp; payment</li>
        <li>3. Confirmation</li>
      </ol>

      <form className="checkout-form" onSubmit={submit} noValidate>
        <section className="checkout-block">
          <h2>Delivery address</h2>
          <div className="field">
            <label htmlFor="name">Full name</label>
            <input
              id="name"
              value={address.name}
              onChange={(event) => set('name', event.target.value)}
              placeholder="Alex Morgan"
              autoComplete="name"
            />
            {errors.name && <span className="field-error">{errors.name}</span>}
          </div>
          <div className="field">
            <label htmlFor="line1">Street address</label>
            <input
              id="line1"
              value={address.line1}
              onChange={(event) => set('line1', event.target.value)}
              placeholder="221B Baker Street, Apt 4"
              autoComplete="street-address"
            />
            {errors.line1 && <span className="field-error">{errors.line1}</span>}
          </div>
          <div className="field-row">
            <div className="field">
              <label htmlFor="city">City</label>
              <input
                id="city"
                value={address.city}
                onChange={(event) => set('city', event.target.value)}
                placeholder="New York"
                autoComplete="address-level2"
              />
              {errors.city && <span className="field-error">{errors.city}</span>}
            </div>
            <div className="field">
              <label htmlFor="postcode">Postcode / ZIP</label>
              <input
                id="postcode"
                value={address.postcode}
                onChange={(event) => set('postcode', event.target.value)}
                placeholder="10001"
                autoComplete="postal-code"
              />
              {errors.postcode && <span className="field-error">{errors.postcode}</span>}
            </div>
          </div>
          <div className="field-row">
            <div className="field">
              <label htmlFor="country">Country</label>
              <select id="country" value={address.country} onChange={(event) => set('country', event.target.value)}>
                {['United States', 'United Kingdom', 'Canada', 'Australia', 'Germany', 'India'].map((country) => (
                  <option key={country}>{country}</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="email">Email for receipt</label>
              <input
                id="email"
                value={address.email}
                onChange={(event) => set('email', event.target.value)}
                placeholder="you@example.com"
                autoComplete="email"
              />
              {errors.email && <span className="field-error">{errors.email}</span>}
            </div>
          </div>
        </section>

        <section className="checkout-block">
          <h2>Payment method</h2>
          <div className="pay-options">
            {[
              { key: 'card', label: 'Card ending 4242', note: 'Visa · expires 04/29' },
              { key: 'balance', label: 'Nexa balance', note: `${currency(125.4)} available` },
              { key: 'later', label: 'Pay in 4', note: 'Four interest-free payments' },
            ].map((option) => (
              <label key={option.key} className={`pay-option${payment === option.key ? ' is-active' : ''}`}>
                <input
                  type="radio"
                  name="payment"
                  value={option.key}
                  checked={payment === option.key}
                  onChange={() => setPayment(option.key)}
                />
                <span>
                  <strong>{option.label}</strong>
                  <em>{option.note}</em>
                </span>
              </label>
            ))}
          </div>
          <p className="checkout-note">
            This is a demo checkout. No card is charged and no payment details are collected.
          </p>
        </section>

        <button type="submit" className="btn btn-primary place-order" disabled={placing}>
          {placing ? 'Placing order…' : `Place your order · ${currency(total)}`}
        </button>
        <p className="checkout-terms">
          By placing your order you agree to Nexa's demo terms. Nothing will be charged or shipped.
        </p>
      </form>

      <aside className="checkout-summary">
        <h2>Order summary</h2>
        <Link to="/cart" className="checkout-edit">
          Edit cart
        </Link>
        <ul className="checkout-lines">
          {items.map(({ product, qty, lineTotal }) => (
            <li key={product.id} className="checkout-line">
              <img src={product.images[0]} alt="" />
              <div>
                <span className="checkout-line-title">{product.title}</span>
                <span className="checkout-line-meta">Qty {qty}</span>
              </div>
              <span>{currency(lineTotal)}</span>
            </li>
          ))}
        </ul>
        <div className="summary-row">
          <span>Items ({count})</span>
          <span>{currency(subtotal)}</span>
        </div>
        <div className="summary-row">
          <span>Delivery</span>
          <span>{shipping === 0 ? 'FREE' : currency(shipping)}</span>
        </div>
        <div className="summary-row">
          <span>Estimated tax</span>
          <span>{currency(tax)}</span>
        </div>
        <div className="summary-row summary-total">
          <span>Order total</span>
          <span>{currency(total)}</span>
        </div>
      </aside>
    </div>
  )
}
