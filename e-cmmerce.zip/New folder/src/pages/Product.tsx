import { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { PrimeBadge } from '../components/ProductCard'
import { ProductRail } from '../components/ProductRail'
import { Stars } from '../components/Stars'
import { products } from '../data/catalogue'
import { useStore } from '../context/StoreContext'
import { currency, deliveryWindow, ratingLabel, shortDate } from '../lib/format'
import { buildReviews } from '../lib/reviews'
import type { Review } from '../types'

function ReviewCard({ review }: { review: Review }) {
  const [voted, setVoted] = useState(false)
  const [helpful, setHelpful] = useState(review.helpful)

  return (
    <article className="review">
      <div className="review-head">
        <span className="review-avatar">{review.author.charAt(0)}</span>
        <span className="review-author">{review.author}</span>
      </div>
      <div className="review-title-row">
        <Stars rating={review.rating} size={14} />
        <h4>{review.title}</h4>
      </div>
      <p className="review-date">
        Reviewed on {shortDate(review.date)}
        {review.verified && <span className="review-verified">Verified Purchase</span>}
      </p>
      <p className="review-body">{review.body}</p>
      <button
        type="button"
        className="review-helpful"
        onClick={() => {
          setVoted(true)
          setHelpful((value) => value + 1)
        }}
        disabled={voted}
      >
        {voted ? 'Thanks for your feedback' : 'Helpful'} · {helpful}
      </button>
    </article>
  )
}

export function ProductPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { addToCart, wishlist, toggleWishlist, markViewed, cart } = useStore()

  const product = products.find((item) => item.id === Number(id))

  const [activeImage, setActiveImage] = useState(0)
  const [qty, setQty] = useState(1)
  const [tab, setTab] = useState<'description' | 'specs'>('description')

  useEffect(() => {
    setActiveImage(0)
    setQty(1)
    if (product) markViewed(product.id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [product?.id])

  const reviews = useMemo(
    () => (product ? buildReviews(product.id, product.rating) : []),
    [product],
  )

  if (!product) {
    return (
      <div className="page-narrow">
        <h1>We couldn't find that product</h1>
        <p>It may have been removed, or the link may be wrong.</p>
        <Link to="/" className="btn btn-primary">
          Back to home
        </Link>
      </div>
    )
  }

  const saved = wishlist.includes(product.id)
  const inCart = cart.find((line) => line.id === product.id)
  const off = product.listPrice
    ? Math.round(((product.listPrice - product.price) / product.listPrice) * 100)
    : 0

  const histogram = [5, 4, 3, 2, 1].map((star) => {
    const count = reviews.filter((review) => review.rating === star).length
    return { star, count, pct: reviews.length ? (count / reviews.length) * 100 : 0 }
  })

  const related = products
    .filter((item) => item.category === product.category && item.id !== product.id)
    .slice(0, 14)

  return (
    <div className="product-page">
      <nav className="crumbs">
        <Link to="/">Home</Link>
        <span>/</span>
        <Link to={`/search?dept=${product.department}`}>{product.departmentLabel}</Link>
        <span>/</span>
        <Link to={`/search?cat=${product.category}`}>{product.categoryLabel}</Link>
        <span>/</span>
        <span className="crumbs-current">{product.title}</span>
      </nav>

      <div className="product-main">
        <div className="gallery">
          <div className="gallery-thumbs">
            {product.images.map((image, index) => (
              <button
                key={image}
                type="button"
                className={index === activeImage ? 'is-active' : ''}
                onMouseEnter={() => setActiveImage(index)}
                onClick={() => setActiveImage(index)}
                aria-label={`View image ${index + 1}`}
              >
                <img src={image} alt="" />
              </button>
            ))}
          </div>
          <div className="gallery-main">
            <img src={product.images[activeImage]} alt={product.title} />
          </div>
        </div>

        <div className="product-info">
          <h1 className="product-title">{product.title}</h1>
          <p className="product-brand">
            Visit the <button type="button" className="link-like">{product.brand}</button> store
          </p>
          <div className="product-rating">
            <span className="product-score">{product.rating.toFixed(1)}</span>
            <Stars rating={product.rating} size={17} />
            <button type="button" className="link-like" onClick={() => setTab('description')}>
              {product.ratingCount.toLocaleString('en-US')} ratings
            </button>
            <span className="product-rating-label">· {ratingLabel(product.rating)}</span>
          </div>

          <hr className="rule" />

          <div className="product-price-row">
            {off > 0 && <span className="deal-off">-{off}%</span>}
            <span className="price price-lg">
              <span className="price-symbol">$</span>
              <span className="price-whole">{product.price.toFixed(2).split('.')[0]}</span>
              <span className="price-fraction">{product.price.toFixed(2).split('.')[1]}</span>
            </span>
          </div>
          {product.listPrice && (
            <p className="product-list-price">
              List Price: <s>{currency(product.listPrice)}</s>
            </p>
          )}
          {product.prime && (
            <p className="product-prime">
              <PrimeBadge /> <span>One-day delivery available</span>
            </p>
          )}

          <p className="product-free">
            <strong>FREE delivery {deliveryWindow(product.deliveryDays - 1)}</strong> on orders over $35
          </p>
          <p className="product-loc">
            Deliver to <strong>your location</strong>
          </p>

          <h2 className={`product-stock${product.stock < 10 ? ' is-low' : ''}`}>
            {product.stock < 10 ? `Only ${product.stock} left in stock — order soon` : 'In stock'}
          </h2>

          <div className="product-buybox">
            <p className="buybox-price">{currency(product.price)}</p>
            <p className="buybox-delivery">
              <strong>FREE delivery {deliveryWindow(product.deliveryDays - 1)}</strong>
            </p>
            <p className="buybox-loc">
              Deliver to your location <span className="buybox-zip">▼</span>
            </p>
            <h3 className={product.stock < 10 ? 'is-low' : ''}>
              {product.stock < 10 ? `Only ${product.stock} left` : 'In stock'}
            </h3>
            <label className="buybox-qty">
              Quantity
              <select value={qty} onChange={(event) => setQty(Number(event.target.value))}>
                {Array.from({ length: Math.min(10, product.stock) }, (_, i) => i + 1).map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
            <button
              type="button"
              className="btn btn-primary btn-block"
              onClick={() => addToCart(product.id, qty)}
            >
              Add to cart
            </button>
            <button
              type="button"
              className="btn btn-buy btn-block"
              onClick={() => {
                addToCart(product.id, qty)
                navigate('/checkout')
              }}
            >
              Buy now
            </button>
            <button
              type="button"
              className="btn btn-ghost btn-block"
              onClick={() => toggleWishlist(product.id)}
            >
              {saved ? '♥ Saved to your list' : '♡ Add to list'}
            </button>
            {inCart && <p className="buybox-incart">{inCart.qty} already in your cart</p>}
            <dl className="buybox-meta">
              <div>
                <dt>Ships from</dt>
                <dd>{product.shipsFrom}</dd>
              </div>
              <div>
                <dt>Sold by</dt>
                <dd>{product.soldBy}</dd>
              </div>
              <div>
                <dt>Returns</dt>
                <dd>30-day refund</dd>
              </div>
            </dl>
          </div>
        </div>
      </div>

      <div className="product-tabs">
        <div className="tab-head">
          <button
            type="button"
            className={tab === 'description' ? 'is-active' : ''}
            onClick={() => setTab('description')}
          >
            About this item
          </button>
          <button
            type="button"
            className={tab === 'specs' ? 'is-active' : ''}
            onClick={() => setTab('specs')}
          >
            Product details
          </button>
        </div>

        {tab === 'description' ? (
          <div className="tab-body">
            <p className="product-desc">{product.description}</p>
            <ul className="feature-list">
              {product.features.map((feature) => (
                <li key={feature}>{feature}</li>
              ))}
            </ul>
          </div>
        ) : (
          <div className="tab-body">
            <table className="spec-table">
              <tbody>
                {product.specs.map((spec) => (
                  <tr key={spec.label}>
                    <th>{spec.label}</th>
                    <td>{spec.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <section className="reviews">
        <div className="reviews-summary">
          <h2>Customer reviews</h2>
          <div className="reviews-score">
            <Stars rating={product.rating} size={20} />
            <span>{product.rating.toFixed(1)} out of 5</span>
          </div>
          <p className="reviews-total">{product.ratingCount.toLocaleString('en-US')} global ratings</p>
          <div className="histogram">
            {histogram.map((row) => (
              <div key={row.star} className="histogram-row">
                <span>{row.star} star</span>
                <div className="histogram-bar">
                  <div style={{ width: `${row.pct}%` }} />
                </div>
                <span className="histogram-pct">{Math.round(row.pct)}%</span>
              </div>
            ))}
          </div>
        </div>
        <div className="reviews-list">
          {reviews.map((review) => (
            <ReviewCard key={review.id} review={review} />
          ))}
        </div>
      </section>

      {related.length > 0 && (
        <ProductRail
          title="Customers also viewed"
          products={related}
          seeMoreTo={`/search?cat=${product.category}`}
        />
      )}
    </div>
  )
}
