import { Link, useSearchParams } from 'react-router-dom'
import { useStore } from '../context/StoreContext'
import { currency, deliveryWindow, shortDate } from '../lib/format'

export function OrdersPage() {
  const { orders, addToCart } = useStore()
  const [params, setParams] = useSearchParams()
  const justPlaced = params.get('placed') === '1'

  return (
    <div className="orders-page">
      {justPlaced && orders.length > 0 && (
        <section className="order-banner">
          <div className="order-banner-check">✓</div>
          <div>
            <h1>Order placed, thank you!</h1>
            <p>
              Confirmation for order <strong>{orders[0].id}</strong> has been sent to{' '}
              <strong>{orders[0].address.email}</strong>. This is a demo — nothing will ship.
            </p>
            <div className="order-banner-actions">
              <Link to="/" className="btn btn-primary">
                Keep shopping
              </Link>
              <button type="button" className="btn btn-ghost" onClick={() => setParams(new URLSearchParams())}>
                Dismiss
              </button>
            </div>
          </div>
        </section>
      )}

      <header className="orders-head">
        <h1>Your Orders</h1>
        <p>{orders.length ? `${orders.length} order${orders.length === 1 ? '' : 's'} placed` : 'No orders yet'}</p>
      </header>

      {orders.length === 0 ? (
        <div className="order-empty">
          <p>You haven't placed any orders yet.</p>
          <Link to="/" className="btn btn-primary">
            Start shopping
          </Link>
        </div>
      ) : (
        <ul className="order-list">
          {orders.map((order) => (
            <li key={order.id} className="order-card">
              <div className="order-head">
                <div className="order-meta">
                  <div>
                    <span>Order placed</span>
                    <strong>{shortDate(order.placedAt)}</strong>
                  </div>
                  <div>
                    <span>Total</span>
                    <strong>{currency(order.total)}</strong>
                  </div>
                  <div>
                    <span>Order number</span>
                    <strong>{order.id}</strong>
                  </div>
                </div>
                <div className="order-status">
                  <span className="order-status-pill">Arriving {deliveryWindow(1).split(' - ')[0]}</span>
                  <span className="order-status-sub">Shipped to {order.address.city}</span>
                </div>
              </div>

              <div className="order-lines">
                {order.lines.map((line) => (
                  <div key={line.id} className="order-line">
                    <img src={line.image} alt="" />
                    <div className="order-line-body">
                      <Link to={`/product/${line.id}`}>{line.title}</Link>
                      <span className="order-line-meta">
                        Qty {line.qty} · {currency(line.price)} each
                      </span>
                      <div className="order-line-actions">
                        <button type="button" className="btn btn-cart btn-sm" onClick={() => addToCart(line.id, line.qty)}>
                          Buy it again
                        </button>
                        <Link to={`/product/${line.id}`} className="link-like">
                          View product
                        </Link>
                      </div>
                    </div>
                    <span className="order-line-price">{currency(line.price * line.qty)}</span>
                  </div>
                ))}
              </div>

              <div className="order-foot">
                <div>
                  <span>Items</span>
                  <strong>{currency(order.subtotal)}</strong>
                </div>
                <div>
                  <span>Delivery</span>
                  <strong>{order.shipping === 0 ? 'FREE' : currency(order.shipping)}</strong>
                </div>
                <div>
                  <span>Tax</span>
                  <strong>{currency(order.tax)}</strong>
                </div>
                <div className="order-foot-total">
                  <span>Total</span>
                  <strong>{currency(order.total)}</strong>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
