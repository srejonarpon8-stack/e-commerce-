import { Link, useParams } from 'react-router-dom'
import { infoPages, infoPageBySlug } from '../data/pages'
import { shortDate } from '../lib/format'
import { NotFoundPage } from './NotFound'

const slugifyHeading = (heading: string) =>
  heading
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')

export function InfoPage() {
  const { slug } = useParams()
  const page = slug ? infoPageBySlug(slug) : undefined

  if (!page) return <NotFoundPage />

  const sameCategory = infoPages.filter(
    (item) => item.category === page.category && item.slug !== page.slug,
  )
  const related = page.related.map((key) => infoPageBySlug(key)).filter((item) => !!item)

  return (
    <div className="info-page">
      <nav className="info-crumbs">
        <Link to="/">Home</Link>
        <span>/</span>
        <span>{page.category}</span>
        <span>/</span>
        <span className="info-crumb-current">{page.title}</span>
      </nav>

      <header className="info-hero">
        <span className="info-eyebrow">{page.category}</span>
        <h1>{page.title}</h1>
        <p className="info-lede">{page.lede}</p>
        <p className="info-updated">Last updated {shortDate(page.updated)}</p>
      </header>

      <div className="info-layout">
        <aside className="info-side">
          <div className="info-toc">
            <h2>On this page</h2>
            <ol>
              {page.sections.map((section) => (
                <li key={section.heading}>
                  <a href={`#${slugifyHeading(section.heading)}`}>{section.heading}</a>
                </li>
              ))}
            </ol>
          </div>

          {sameCategory.length > 0 && (
            <div className="info-side-links">
              <h2>More in {page.category}</h2>
              <ul>
                {sameCategory.slice(0, 6).map((item) => (
                  <li key={item.slug}>
                    <Link to={`/info/${item.slug}`}>{item.title}</Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </aside>

        <article className="info-body">
          {page.sections.map((section) => (
            <section key={section.heading} id={slugifyHeading(section.heading)} className="info-section">
              <h2>{section.heading}</h2>
              {section.body.map((paragraph) => (
                <p key={paragraph.slice(0, 40)}>{paragraph}</p>
              ))}
              {section.bullets && (
                <ul className="info-bullets">
                  {section.bullets.map((bullet) => (
                    <li key={bullet}>{bullet}</li>
                  ))}
                </ul>
              )}
            </section>
          ))}

          <div className="info-cta">
            <div>
              <h2>Need something else?</h2>
              <p>Browse the catalogue, or ask Nexa Assist in the corner — it answers questions about this store and anything else.</p>
            </div>
            <div className="info-cta-actions">
              <Link to="/" className="btn btn-primary">
                Start shopping
              </Link>
              <Link to="/info/help" className="btn btn-ghost">
                All help topics
              </Link>
            </div>
          </div>

          {related.length > 0 && (
            <div className="info-related">
              <h2>Related</h2>
              <ul>
                {related.map((item) => (
                  <li key={item.slug}>
                    <Link to={`/info/${item.slug}`}>{item.title}</Link>
                    <span>{item.lede}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </article>
      </div>
    </div>
  )
}
