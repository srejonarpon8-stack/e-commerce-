import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { CategoryCard, DepartmentCard, SidebarCard } from '../components/CategoryCards'
import { HeroCarousel } from '../components/HeroCarousel'
import { ProductRail } from '../components/ProductRail'
import { PrimeBadge } from '../components/ProductCard'
import { RatingLine } from '../components/Stars'
import { categories, departments, products } from '../data/catalogue'
import { findProduct, useStore } from '../context/StoreContext'
import { currency } from '../lib/format'
import type { Product } from '../types'

const discountPct = (product: Product) =>
  product.listPrice ? ((product.listPrice - product.price) / product.listPrice) * 100 : 0

function useCountdown() {
  const [left, setLeft] = useState('')
  useEffect(() => {
    const tick = () => {
      const now = new Date()
      const end = new Date(now)
      end.setHours(23, 59, 59, 999)
      const diff = Math.max(0, end.getTime() - now.getTime())
      const h = Math.floor(diff / 3_600_000)
      const m = Math.floor((diff % 3_600_000) / 60_000)
      const s = Math.floor((diff % 60_000) / 1000)
      setLeft(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`)
    }
    tick()
    const timer = window.setInterval(tick, 1000)
    return () => window.clearInterval(timer)
  }, [])
  return left
}

function DealBanner() {
  const countdown = useCountdown()
  const deal = products.filter((p) => p.listPrice).sort((a, b) => discountPct(b) - discountPct(a))[0]

  return (
    <section className="deal-banner">
      <div className="deal-copy">
        <span className="deal-eyebrow">Deal of the day</span>
        <h2>{deal.title}</h2>
        <div className="deal-price-row">
          <span className="deal-price">{currency(deal.price)}</span>
          {deal.listPrice && <s className="deal-list">{currency(deal.listPrice)}</s>}
          <span className="deal-off">Save {Math.round(discountPct(deal))}%</span>
        </div>
        <p>Ends in <strong>{countdown}</strong> — one per customer while stock lasts.</p>
        <div className="deal-actions">
          <Link to={`/product/${deal.id}`} className="btn btn-primary">
            Shop this deal
          </Link>
          <Link to="/search?deals=1" className="deal-link">
            See all deals
          </Link>
        </div>
      </div>
      <Link to={`/product/${deal.id}`} className="deal-art">
        <img src={deal.images[0]} alt={deal.title} loading="lazy" />
      </Link>
    </section>
  )
}

function TrendingStrip() {
  const top = [...products].sort((a, b) => b.ratingCount - a.ratingCount).slice(0, 6)
  return (
    <section className="trending">
      <h2>Trending now</h2>
      <div className="trending-grid">
        {top.map((product, index) => (
          <Link to={`/product/${product.id}`} key={product.id} className="trending-item">
            <span className="trending-rank">{index + 1}</span>
            <img src={product.images[0]} alt="" loading="lazy" />
            <span className="trending-title">{product.title}</span>
            <RatingLine rating={product.rating} count={product.ratingCount} size={12} />
            <span className="trending-price">{currency(product.price)}</span>
            {product.prime && <PrimeBadge />}
          </Link>
        ))}
      </div>
    </section>
  )
}

export function HomePage() {
  const { recentlyViewed } = useStore()

  const deals = products
    .filter((p) => p.listPrice)
    .sort((a, b) => discountPct(b) - discountPct(a))
    .slice(0, 14)
  const bestSellers = [...products].sort((a, b) => b.ratingCount - a.ratingCount).slice(0, 14)
  const topRated = [...products].filter((p) => p.rating >= 4.5).sort((a, b) => b.rating - a.rating).slice(0, 14)
  const electronics = products.filter((p) => p.department === 'electronics').slice(0, 14)
  const homeKitchen = products.filter((p) => p.department === 'home').slice(0, 14)
  const fashion = products.filter((p) => p.department === 'fashion').slice(0, 14)
  const newArrivals = [...products].sort((a, b) => b.createdAt - a.createdAt).slice(0, 14)
  const recent = recentlyViewed.map((id) => findProduct(id)).filter((p): p is Product => !!p)

  return (
    <div className="home">
      <HeroCarousel />

      <div className="home-grid">
        {departments.slice(0, 3).map((dept) => (
          <DepartmentCard key={dept.key} department={dept} />
        ))}
        <SidebarCard />
      </div>

      <ProductRail title="Deals for you" products={deals} seeMoreTo="/search?deals=1" />

      <div className="home-grid home-grid-4">
        {categories.slice(0, 8).map((category) => (
          <CategoryCard key={category.slug} category={category} />
        ))}
      </div>

      <DealBanner />

      <ProductRail title="Best sellers" products={bestSellers} seeMoreTo="/search?sort=reviews" />
      <ProductRail title="Top rated in every aisle" products={topRated} seeMoreTo="/search?sort=rating" />
      <ProductRail title="Electronics picks" products={electronics} seeMoreTo="/search?dept=electronics" />
      <ProductRail title="Home & kitchen" products={homeKitchen} seeMoreTo="/search?dept=home" />
      <ProductRail title="Fashion under the spotlight" products={fashion} seeMoreTo="/search?dept=fashion" />

      <TrendingStrip />

      <ProductRail title="New arrivals" products={newArrivals} seeMoreTo="/search?sort=new" />

      {recent.length > 0 && (
        <ProductRail title="Recently viewed" products={recent} seeMoreTo="/search" />
      )}

      <section className="home-cta">
        <div>
          <h2>See personalised recommendations</h2>
          <p>Sign in to build a profile, save lists and get picks tuned to what you actually buy.</p>
        </div>
        <button type="button" className="btn btn-primary">
          Sign in securely
        </button>
      </section>
    </div>
  )
}
