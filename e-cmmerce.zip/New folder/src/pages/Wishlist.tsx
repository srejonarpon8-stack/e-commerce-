import { Link } from 'react-router-dom'
import { ProductCard } from '../components/ProductCard'
import { findProduct, useStore } from '../context/StoreContext'
import { currency } from '../lib/format'
import type { Product } from '../types'

export function WishlistPage() {
  const { wishlist } = useStore()
  const saved = wishlist.map((id) => findProduct(id)).filter((p): p is Product => !!p)
  const total = saved.reduce((sum, product) => sum + product.price, 0)

  return (
    <div className="wishlist-page">
      <header className="wishlist-head">
        <div>
          <h1>Your Lists</h1>
          <p>{saved.length ? `${saved.length} saved item${saved.length === 1 ? '' : 's'} · ${currency(total)} total` : 'Nothing saved yet'}</p>
        </div>
        <Link to="/" className="btn btn-ghost">
          Continue shopping
        </Link>
      </header>

      {saved.length === 0 ? (
        <div className="order-empty">
          <p>Tap the heart on any product to keep it here for later.</p>
          <Link to="/search?deals=1" className="btn btn-primary">
            Browse today's deals
          </Link>
        </div>
      ) : (
        <div className="wishlist-grid">
          {saved.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}
