import { Link } from 'react-router-dom'

export function NotFoundPage() {
  return (
    <div className="page-narrow notfound">
      <img src="https://cdn.dummyjson.com/product-images/beauty/essence-mascara-lash-princess/1.webp" alt="" />
      <h1>Sorry, we couldn't find that page</h1>
      <p>The link may be broken, or the page may have moved. Try searching instead.</p>
      <div className="notfound-actions">
        <Link to="/" className="btn btn-primary">
          Go to Nexa home
        </Link>
        <Link to="/search" className="btn btn-ghost">
          Browse all products
        </Link>
      </div>
    </div>
  )
}
