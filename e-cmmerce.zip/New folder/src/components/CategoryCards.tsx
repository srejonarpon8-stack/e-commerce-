import { Link } from 'react-router-dom'
import type { Category, Department } from '../types'
import { products } from '../data/catalogue'

interface DepartmentCardProps {
  department: Department
}

export function DepartmentCard({ department }: DepartmentCardProps) {
  const items = products.filter((p) => p.department === department.key)
  const tiles = items.slice(0, 4)
  const label = department.label.split(',')[0].split(' & ')[0]

  return (
    <section className="dept-card">
      <h2>{department.label}</h2>
      <div className="dept-tiles">
        {tiles.map((product) => (
          <Link key={product.id} to={`/product/${product.id}`} className="dept-tile">
            <img src={product.images[0]} alt={product.title} loading="lazy" />
            <span>{product.categoryLabel}</span>
          </Link>
        ))}
      </div>
      <Link to={`/search?dept=${department.key}`} className="dept-more">
        See more {label.toLowerCase()}
      </Link>
    </section>
  )
}

interface CategoryCardProps {
  category: Category
}

export function CategoryCard({ category }: CategoryCardProps) {
  const items = products.filter((p) => p.category === category.slug).slice(0, 4)
  return (
    <section className="dept-card">
      <h2>{category.label}</h2>
      <div className="dept-tiles">
        {items.map((product) => (
          <Link key={product.id} to={`/product/${product.id}`} className="dept-tile">
            <img src={product.images[0]} alt={product.title} loading="lazy" />
          </Link>
        ))}
      </div>
      <Link to={`/search?cat=${category.slug}`} className="dept-more">
        See more
      </Link>
    </section>
  )
}

export function SidebarCard() {
  return (
    <section className="dept-card sidecard">
      <h2>Sign in for the best experience</h2>
      <button type="button" className="btn btn-primary btn-block">
        Sign in securely
      </button>
      <div className="sidecard-promo">
        <span>New to Nexa?</span>
        <a href="#top" onClick={(event) => event.preventDefault()}>
          Create an account
        </a>
      </div>
    </section>
  )
}
