import { Link } from 'react-router-dom'
import { useStore } from '../context/StoreContext'
import { currency } from '../lib/format'
import type { Product } from '../types'
import { RatingLine } from './Stars'

interface ProductCardProps {
  product: Product
  compact?: boolean
}

export function PrimeBadge() {
  return (
    <span className="prime" title="Fast, free delivery on eligible orders">
      <span className="prime-check">✓</span>
      <span className="prime-word">prime</span>
    </span>
  )
}

export function ProductCard({ product, compact = false }: ProductCardProps) {
  const { addToCart, wishlist, toggleWishlist } = useStore()
  const saved = wishlist.includes(product.id)
  const discount = product.listPrice
    ? Math.round(((product.listPrice - product.price) / product.listPrice) * 100)
    : 0

  return (
    <article className={`pcard${compact ? ' pcard-compact' : ''}`}>
      <button
        type="button"
        className={`pcard-heart${saved ? ' is-saved' : ''}`}
        aria-label={saved ? 'Remove from your list' : 'Save for later'}
        aria-pressed={saved}
        onClick={() => toggleWishlist(product.id)}
      >
        {saved ? '♥' : '♡'}
      </button>

      <Link to={`/product/${product.id}`} className="pcard-media" tabIndex={-1} aria-hidden="true">
        <img src={product.images[0]} alt="" loading="lazy" />
      </Link>

      <div className="pcard-body">
        <Link to={`/product/${product.id}`} className="pcard-title">
          {product.title}
        </Link>
        <RatingLine rating={product.rating} count={product.ratingCount} />
        <div className="pcard-price">
          <span className="price">
            <span className="price-symbol">$</span>
            <span className="price-whole">{product.price.toFixed(2).split('.')[0]}</span>
            <span className="price-fraction">{product.price.toFixed(2).split('.')[1]}</span>
          </span>
          {product.listPrice && (
            <span className="price-list">
              List: <s>{currency(product.listPrice)}</s>
              {discount > 0 && <span className="price-off"> -{discount}%</span>}
            </span>
          )}
        </div>
        {product.prime && <PrimeBadge />}
        <p className="pcard-delivery">FREE delivery in {product.deliveryDays} days</p>
        <button type="button" className="btn btn-cart" onClick={() => addToCart(product.id)}>
          Add to cart
        </button>
      </div>
    </article>
  )
}
