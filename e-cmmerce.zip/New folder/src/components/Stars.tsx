interface StarsProps {
  rating: number
  size?: number
  className?: string
}

export function Stars({ rating, size = 14, className = '' }: StarsProps) {
  const percent = Math.max(0, Math.min(100, (rating / 5) * 100))
  return (
    <span
      className={`stars ${className}`}
      style={{ fontSize: size }}
      role="img"
      aria-label={`${rating.toFixed(1)} out of 5 stars`}
    >
      <span className="stars-track" aria-hidden="true">
        ★★★★★
      </span>
      <span className="stars-fill" style={{ width: `${percent}%` }} aria-hidden="true">
        ★★★★★
      </span>
    </span>
  )
}

interface RatingLineProps {
  rating: number
  count: number
  size?: number
}

export function RatingLine({ rating, count, size = 13 }: RatingLineProps) {
  return (
    <span className="rating-line">
      <Stars rating={rating} size={size} />
      <span className="rating-count">{count.toLocaleString('en-US')}</span>
    </span>
  )
}
