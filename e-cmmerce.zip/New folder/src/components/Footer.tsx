import { Link } from 'react-router-dom'
import { departments } from '../data/catalogue'

interface FooterLink {
  label: string
  to?: string
  slug?: string
}

const COLUMNS: { title: string; links: FooterLink[] }[] = [
  {
    title: 'Get to Know Us',
    links: [
      { label: 'Careers', slug: 'careers' },
      { label: 'Blog', slug: 'blog' },
      { label: 'About Nexa', slug: 'about' },
      { label: 'Investor Relations', slug: 'investors' },
      { label: 'Nexa Devices', slug: 'devices' },
      { label: 'Science', slug: 'science' },
    ],
  },
  {
    title: 'Make Money with Us',
    links: [
      { label: 'Sell on Nexa', slug: 'sell' },
      { label: 'Become an Affiliate', slug: 'affiliate' },
      { label: 'Advertise Your Products', slug: 'advertise' },
      { label: 'Self-Publish', slug: 'self-publish' },
      { label: 'Host a Hub', slug: 'host-a-hub' },
    ],
  },
  {
    title: 'Payment Products',
    links: [
      { label: 'Nexa Business Card', slug: 'business-card' },
      { label: 'Shop with Points', slug: 'points' },
      { label: 'Reload Your Balance', slug: 'reload-balance' },
      { label: 'Currency Converter', slug: 'currency' },
    ],
  },
  {
    title: 'Let Us Help You',
    links: [
      { label: 'Your Account', slug: 'account' },
      { label: 'Your Orders', to: '/orders' },
      { label: 'Shipping Rates & Policies', slug: 'shipping' },
      { label: 'Returns & Replacements', slug: 'returns' },
      { label: 'Help', slug: 'help' },
    ],
  },
]

export function Footer() {
  return (
    <footer className="footer">
      <button
        type="button"
        className="footer-top"
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      >
        Back to top
      </button>

      <div className="footer-main">
        <div className="footer-cols">
          {COLUMNS.map((column) => (
            <div key={column.title} className="footer-col">
              <h4>{column.title}</h4>
              <ul>
                {column.links.map((link) => (
                  <li key={link.label}>
                    {link.slug ? (
                      <Link to={`/info/${link.slug}`}>{link.label}</Link>
                    ) : (
                      <Link to={link.to || '/'}>{link.label}</Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="footer-departments">
          {departments.map((dept) => (
            <Link key={dept.key} to={`/search?dept=${dept.key}`}>
              {dept.label}
            </Link>
          ))}
        </div>

        <div className="footer-brand">
          <div className="footer-logo">
            <span className="brand-word">nexa</span>
            <svg className="brand-smile" viewBox="0 0 100 26" aria-hidden="true">
              <path d="M4 6c14 16 64 20 92 2" fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
              <path d="M88 3l8 5-9 4z" fill="currentColor" />
            </svg>
          </div>
          <div className="footer-legal-links">
            <Link to="/info/terms">Conditions of Use</Link>
            <Link to="/info/privacy">Privacy Notice</Link>
            <Link to="/info/ad-choices">Your Ads Privacy Choices</Link>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <span>© 1996–{new Date().getFullYear()}, Nexa.com, Inc. or its affiliates</span>
        <span className="footer-demo">
          Demo storefront — product data and photography are sample content, no real orders are placed.
        </span>
      </div>
    </footer>
  )
}
