import { useEffect, useMemo, useRef, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { findProduct, useStore } from '../context/StoreContext'
import { currency } from '../lib/format'
import type { ChatMessage } from '../types'

const SUGGESTIONS = [
  'What are the best deals on this site right now?',
  'Explain the difference between a tablet and a laptop',
  'Help me plan a simple dinner with pantry staples',
  'How do I track my order?',
]

function Rich({ text }: { text: string }) {
  const blocks: React.ReactNode[] = []
  const lines = text.split('\n')
  let list: string[] = []

  const flushList = (key: string) => {
    if (!list.length) return
    blocks.push(
      <ul key={key}>
        {list.map((item, i) => (
          <li key={i}>{inline(item)}</li>
        ))}
      </ul>,
    )
    list = []
  }

  lines.forEach((raw, index) => {
    const line = raw.trimEnd()
    if (/^\s*([-*•]|\d+\.)\s+/.test(line)) {
      list.push(line.replace(/^\s*([-*•]|\d+\.)\s+/, ''))
      return
    }
    flushList(`list-${index}`)
    if (!line.trim()) return
    if (line.startsWith('### ')) {
      blocks.push(<h4 key={index}>{inline(line.slice(4))}</h4>)
    } else if (line.startsWith('## ')) {
      blocks.push(<h3 key={index}>{inline(line.slice(3))}</h3>)
    } else if (line.startsWith('# ')) {
      blocks.push(<h3 key={index}>{inline(line.slice(2))}</h3>)
    } else {
      blocks.push(<p key={index}>{inline(line)}</p>)
    }
  })
  flushList('list-end')

  return <div className="chat-rich">{blocks}</div>
}

function inline(text: string): React.ReactNode {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)/g).filter(Boolean)
  return parts.map((part, index) => {
    if (part.startsWith('**') && part.endsWith('**')) return <strong key={index}>{part.slice(2, -2)}</strong>
    if (part.startsWith('`') && part.endsWith('`')) return <code key={index}>{part.slice(1, -1)}</code>
    if (part.startsWith('*') && part.endsWith('*') && part.length > 2)
      return <em key={index}>{part.slice(1, -1)}</em>
    return <span key={index}>{part}</span>
  })
}

export function ChatWidget() {
  const location = useLocation()
  const { items, count, subtotal, wishlist } = useStore()
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<{ code: string; message: string } | null>(null)
  const bodyRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const productContext = useMemo(() => {
    const match = location.pathname.match(/^\/product\/(\d+)/)
    if (!match) return null
    return findProduct(Number(match[1])) ?? null
  }, [location.pathname])

  useEffect(() => {
    if (!open) return
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  useEffect(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight
  }, [messages, busy, open])

  useEffect(() => {
    if (open) inputRef.current?.focus()
  }, [open])

  const systemPrompt = () => {
    const context: string[] = [
      'You are Nexa Assist, the in-store assistant for Nexa, a large online retailer.',
      'You are a general-purpose assistant: you can talk about anything — science, cooking, travel, coding, health, history, advice, brainstorming — not just shopping.',
      'When a question is about products or this store, be practical and specific. When it is about anything else, answer it directly and well.',
      'Be concise: two or three short paragraphs or a short list. Use plain language. Never invent order numbers or prices.',
      count > 0
        ? `The shopper currently has ${count} item(s) in the cart worth ${currency(subtotal)}: ${items
            .slice(0, 5)
            .map((i) => i.product.title)
            .join('; ')}.`
        : 'The shopper has an empty cart.',
      wishlist.length ? `They have ${wishlist.length} item(s) saved to their list.` : '',
      productContext
        ? `They are viewing "${productContext.title}" (${productContext.brand}, ${currency(
            productContext.price,
          )}, rated ${productContext.rating}/5 from ${productContext.ratingCount} reviews, category ${productContext.categoryLabel}).`
        : '',
      'If they ask you to buy something, explain they can add it to the cart themselves — you cannot place orders.',
    ]
    return context.filter(Boolean).join(' ')
  }

  const send = async (text: string) => {
    const trimmed = text.trim()
    if (!trimmed || busy) return
    setError(null)
    setInput('')
    const next: ChatMessage[] = [...messages, { role: 'user', content: trimmed }]
    setMessages(next)
    setBusy(true)

    const payload = [
      { role: 'system', content: systemPrompt() },
      ...next.slice(-16).map((m) => ({ role: m.role, content: m.content })),
    ]

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ messages: payload }),
      })

      if (!response.ok) {
        const data = await response.json().catch(() => ({}))
        if (response.status === 503) {
          setError({
            code: 'chat_not_configured',
            message:
              data.message ||
              'Add an OPENAI_API_KEY to this project\'s .env file to switch the assistant on.',
          })
        } else {
          setError({
            code: data.error || 'error',
            message: data.detail || data.message || `The assistant returned ${response.status}.`,
          })
        }
        setBusy(false)
        return
      }

      if (!response.body) {
        setError({ code: 'no_stream', message: 'The assistant did not return a stream.' })
        setBusy(false)
        return
      }

      setMessages([...next, { role: 'assistant', content: '' }])
      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''
      let answer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() ?? ''
        for (const line of lines) {
          const trimmedLine = line.trim()
          if (!trimmedLine.startsWith('data:')) continue
          const data = trimmedLine.slice(5).trim()
          if (!data || data === '[DONE]') continue
          try {
            const parsed = JSON.parse(data)
            const delta = parsed?.choices?.[0]?.delta?.content
            if (typeof delta === 'string' && delta) {
              answer += delta
              setMessages([...next, { role: 'assistant', content: answer }])
            }
          } catch {
            /* partial JSON across chunks — ignore */
          }
        }
      }

      if (!answer) {
        setMessages([...next, { role: 'assistant', content: 'I did not get a reply. Please try again.' }])
      }
    } catch {
      setError({ code: 'network', message: 'Could not reach the assistant. Check your connection and retry.' })
    } finally {
      setBusy(false)
    }
  }

  const onKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      void send(input)
    }
  }

  return (
    <>
      <button
        type="button"
        className={`chat-fab${open ? ' is-open' : ''}`}
        onClick={() => setOpen((value) => !value)}
        aria-label={open ? 'Close assistant' : 'Open the Nexa assistant'}
        aria-expanded={open}
      >
        {open ? '✕' : '✨'}
        {!open && <span className="chat-fab-label">Ask Nexa</span>}
      </button>

      {open && (
        <section className="chat-panel" aria-label="Nexa assistant">
          <header className="chat-head">
            <div>
              <strong>Nexa Assist</strong>
              <span className="chat-sub">
                {productContext ? `Looking at ${productContext.brand}` : 'Ask about anything'}
              </span>
            </div>
            <div className="chat-head-actions">
              <button
                type="button"
                onClick={() => {
                  setMessages([])
                  setError(null)
                }}
                title="New conversation"
              >
                ↺
              </button>
              <button type="button" onClick={() => setOpen(false)} aria-label="Close assistant">
                ✕
              </button>
            </div>
          </header>

          <div className="chat-body" ref={bodyRef}>
            {messages.length === 0 && !error && (
              <div className="chat-empty">
                <p className="chat-hello">
                  Hi — I'm Nexa Assist. Ask me about a product, compare two options, or talk about
                  anything else entirely.
                </p>
                <div className="chat-suggestions">
                  {SUGGESTIONS.map((suggestion) => (
                    <button key={suggestion} type="button" onClick={() => void send(suggestion)}>
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((message, index) => (
              <div key={index} className={`chat-msg chat-${message.role}`}>
                {message.role === 'assistant' && <span className="chat-avatar">n</span>}
                <div className="chat-bubble">
                  {message.content ? <Rich text={message.content} /> : <span className="chat-typing" />}
                </div>
              </div>
            ))}

            {busy && messages[messages.length - 1]?.role === 'user' && (
              <div className="chat-msg chat-assistant">
                <span className="chat-avatar">n</span>
                <div className="chat-bubble">
                  <span className="chat-typing" />
                </div>
              </div>
            )}

            {error && (
              <div className="chat-error">
                <strong>
                  {error.code === 'chat_not_configured' ? 'Assistant not switched on yet' : 'Something went wrong'}
                </strong>
                <p>{error.message}</p>
                {error.code === 'chat_not_configured' && (
                  <ol>
                    <li>
                      Open <code>freebuff.com/account/api</code> and create a key.
                    </li>
                    <li>
                      Add <code>OPENAI_API_KEY=…</code> to <code>.env</code> in the project root.
                    </li>
                    <li>Restart the dev server.</li>
                  </ol>
                )}
              </div>
            )}
          </div>

          <form
            className="chat-input"
            onSubmit={(event) => {
              event.preventDefault()
              void send(input)
            }}
          >
            <textarea
              ref={inputRef}
              value={input}
              rows={1}
              placeholder="Message Nexa Assist…"
              onChange={(event) => setInput(event.target.value)}
              onKeyDown={onKeyDown}
            />
            <button type="submit" disabled={busy || !input.trim()} aria-label="Send message">
              ↑
            </button>
          </form>
          <p className="chat-foot">Replies are generated by AI and may be wrong. Demo storefront.</p>
        </section>
      )}
    </>
  )
}
