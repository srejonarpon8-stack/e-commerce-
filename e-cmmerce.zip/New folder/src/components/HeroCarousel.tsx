import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { products } from '../data/catalogue'
import { currency } from '../lib/format'

const SLIDES = [
  {
    eyebrow: 'New season, new setup',
    title: 'Tech that keeps up with you',
    body: 'Laptops, tablets and audio from the brands people actually keep. Save up to 30% this week.',
    cta: 'Shop electronics',
    to: '/search?dept=electronics',
    category: 'laptops',
    theme: 'slate',
  },
  {
    eyebrow: 'Home refresh event',
    title: 'Make the room feel finished',
    body: 'Furniture, décor and kitchen essentials with free delivery on orders over $35.',
    cta: 'Shop home & kitchen',
    to: '/search?dept=home',
    category: 'furniture',
    theme: 'sand',
  },
  {
    eyebrow: 'Everyday beauty',
    title: 'Skincare, fragrance, essentials',
    body: 'Dermatologist-tested formulas and cult favourites, all in one aisle.',
    cta: 'Shop beauty',
    to: '/search?dept=beauty',
    category: 'beauty',
    theme: 'rose',
  },
]

export function HeroCarousel() {
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)
  const timer = useRef<number | null>(null)

  useEffect(() => {
    if (paused) return
    timer.current = window.setTimeout(() => setIndex((i) => (i + 1) % SLIDES.length), 6500)
    return () => {
      if (timer.current) window.clearTimeout(timer.current)
    }
  }, [index, paused])

  const slide = SLIDES[index]
  const product =
    products.find((p) => p.category === slide.category) ?? products[0]

  return (
    <section
      className={`hero hero-${slide.theme}`}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      aria-roledescription="carousel"
    >
      <div className="hero-inner">
        <div className="hero-copy" key={`copy-${index}`}>
          <span className="hero-eyebrow">{slide.eyebrow}</span>
          <h1>{slide.title}</h1>
          <p>{slide.body}</p>
          <Link to={slide.to} className="btn btn-hero">
            {slide.cta}
          </Link>
          <div className="hero-price">
            Featured: {product.title} · <strong>{currency(product.price)}</strong>
          </div>
        </div>
        <div className="hero-art" key={`art-${index}`}>
          <div className="hero-glow" />
          <img src={product.images[0]} alt={product.title} />
        </div>
      </div>

      <button
        type="button"
        className="hero-arrow hero-prev"
        aria-label="Previous slide"
        onClick={() => setIndex((i) => (i - 1 + SLIDES.length) % SLIDES.length)}
      >
        ‹
      </button>
      <button
        type="button"
        className="hero-arrow hero-next"
        aria-label="Next slide"
        onClick={() => setIndex((i) => (i + 1) % SLIDES.length)}
      >
        ›
      </button>

      <div className="hero-dots">
        {SLIDES.map((item, i) => (
          <button
            key={item.title}
            type="button"
            className={i === index ? 'is-active' : ''}
            aria-label={`Go to slide ${i + 1}`}
            onClick={() => setIndex(i)}
          />
        ))}
      </div>
    </section>
  )
}
