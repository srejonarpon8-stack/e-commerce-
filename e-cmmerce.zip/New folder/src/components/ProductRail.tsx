import { useRef } from 'react'
import { Link } from 'react-router-dom'
import type { Product } from '../types'
import { ProductCard } from './ProductCard'

interface ProductRailProps {
  title: string
  products: Product[]
  seeMoreTo: string
}

export function ProductRail({ title, products: items, seeMoreTo }: ProductRailProps) {
  const trackRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: number) => {
    const el = trackRef.current
    if (!el) return
    el.scrollBy({ left: direction * Math.max(320, el.clientWidth * 0.8), behavior: 'smooth' })
  }

  if (!items.length) return null

  return (
    <section className="rail">
      <div className="rail-head">
        <h2>{title}</h2>
        <Link to={seeMoreTo}>See more</Link>
      </div>
      <div className="rail-wrap">
        <button type="button" className="rail-arrow rail-prev" aria-label="Scroll left" onClick={() => scroll(-1)}>
          ‹
        </button>
        <div className="rail-track" ref={trackRef}>
          {items.map((product) => (
            <div className="rail-item" key={product.id}>
              <ProductCard product={product} compact />
            </div>
          ))}
        </div>
        <button type="button" className="rail-arrow rail-next" aria-label="Scroll right" onClick={() => scroll(1)}>
          ›
        </button>
      </div>
    </section>
  )
}
