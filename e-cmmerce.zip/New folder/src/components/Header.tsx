import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { categories, departments, products } from '../data/catalogue'
import { useStore } from '../context/StoreContext'
import { currency } from '../lib/format'

function SearchIcon() {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
      <circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M15.5 15.5 21 21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

function CartIcon() {
  return (
    <svg viewBox="0 0 24 24" width="34" height="34" aria-hidden="true">
      <path
        d="M2 4h3l2.6 11.2A2 2 0 0 0 9.55 17h8.2a2 2 0 0 0 1.95-1.55L21.5 8H6"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="10" cy="20" r="1.5" fill="currentColor" />
      <circle cx="18" cy="20" r="1.5" fill="currentColor" />
    </svg>
  )
}

function PinIcon() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
      <path
        d="M12 22s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
      />
      <circle cx="12" cy="11" r="2.6" fill="currentColor" />
    </svg>
  )
}

export function Header() {
  const navigate = useNavigate()
  const { count, postcode, setPostcode, orders } = useStore()
  const [query, setQuery] = useState('')
  const [scope, setScope] = useState('all')
  const [focused, setFocused] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [locOpen, setLocOpen] = useState(false)
  const [zipDraft, setZipDraft] = useState(postcode)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const searchRef = useRef<HTMLDivElement>(null)

  const suggestions = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (q.length < 2) return []
    return products
      .filter((p) => p.title.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q))
      .slice(0, 7)
  }, [query])

  useEffect(() => {
    const onDocClick = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) setFocused(false)
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [])

  const submit = (event: React.FormEvent) => {
    event.preventDefault()
    setFocused(false)
    const params = new URLSearchParams()
    if (query.trim()) params.set('q', query.trim())
    if (scope !== 'all') {
      const asDept = departments.find((d) => d.key === scope)
      if (asDept) params.set('dept', scope)
      else params.set('cat', scope)
    }
    navigate(`/search?${params.toString()}`)
  }

  const savePostcode = (event: React.FormEvent) => {
    event.preventDefault()
    if (zipDraft.trim()) setPostcode(zipDraft.trim().toUpperCase())
    setLocOpen(false)
  }

  return (
    <header className="hdr">
      <div className="hdr-top">
        <button
          type="button"
          className="hdr-burger"
          aria-label="Open menu"
          onClick={() => setDrawerOpen(true)}
        >
          ☰
        </button>

        <Link to="/" className="brand" aria-label="Nexa home">
          <span className="brand-word">nexa</span>
          <svg className="brand-smile" viewBox="0 0 100 26" aria-hidden="true">
            <path
              d="M4 6c14 16 64 20 92 2"
              fill="none"
              stroke="currentColor"
              strokeWidth="5"
              strokeLinecap="round"
            />
            <path d="M88 3l8 5-9 4z" fill="currentColor" />
          </svg>
        </Link>

        <button type="button" className="hdr-loc" onClick={() => setLocOpen(true)}>
          <span className="hdr-loc-icon">
            <PinIcon />
          </span>
          <span className="hdr-loc-text">
            <span className="hdr-loc-small">Deliver to</span>
            <span className="hdr-loc-strong">Your location {postcode}</span>
          </span>
        </button>

        <div className="hdr-search" ref={searchRef}>
          <form onSubmit={submit} role="search">
            <select
              className="hdr-scope"
              value={scope}
              aria-label="Search category"
              onChange={(event) => setScope(event.target.value)}
            >
              <option value="all">All</option>
              {departments.map((dept) => (
                <option key={dept.key} value={dept.key}>
                  {dept.label}
                </option>
              ))}
              {categories.map((cat) => (
                <option key={cat.slug} value={cat.slug}>
                  {cat.label}
                </option>
              ))}
            </select>
            <input
              className="hdr-input"
              value={query}
              placeholder="Search Nexa"
              aria-label="Search Nexa"
              onChange={(event) => setQuery(event.target.value)}
              onFocus={() => setFocused(true)}
            />
            <button type="submit" className="hdr-go" aria-label="Search">
              <SearchIcon />
            </button>
          </form>

          {focused && suggestions.length > 0 && (
            <ul className="suggest">
              {suggestions.map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setFocused(false)
                      setQuery('')
                      navigate(`/product/${item.id}`)
                    }}
                  >
                    <img src={item.images[0]} alt="" />
                    <span className="suggest-text">
                      <span className="suggest-title">{item.title}</span>
                      <span className="suggest-meta">
                        {item.categoryLabel} · {currency(item.price)}
                      </span>
                    </span>
                  </button>
                </li>
              ))}
              <li className="suggest-all">
                <button type="button" onClick={(event) => submit(event as unknown as React.FormEvent)}>
                  See all results for “{query.trim()}”
                </button>
              </li>
            </ul>
          )}
        </div>

        <div
          className="hdr-account"
          onMouseEnter={() => setMenuOpen(true)}
          onMouseLeave={() => setMenuOpen(false)}
        >
          <button type="button" className="hdr-link" onClick={() => setMenuOpen((open) => !open)}>
            <span className="hdr-loc-small">Hello, sign in</span>
            <span className="hdr-loc-strong">Account &amp; Lists ▾</span>
          </button>
          {menuOpen && (
            <div className="account-menu">
              <button type="button" className="btn btn-primary account-signin">
                Sign in
              </button>
              <p className="account-new">New customer? Start here.</p>
              <div className="account-links">
                <Link to="/orders" onClick={() => setMenuOpen(false)}>
                  Your Orders
                </Link>
                <Link to="/wishlist" onClick={() => setMenuOpen(false)}>
                  Your Lists
                </Link>
                <Link to="/cart" onClick={() => setMenuOpen(false)}>
                  Your Cart
                </Link>
              </div>
            </div>
          )}
        </div>

        <Link to="/orders" className="hdr-link hdr-orders">
          <span className="hdr-loc-small">Returns</span>
          <span className="hdr-loc-strong">&amp; Orders</span>
        </Link>

        <Link to="/cart" className="hdr-cart">
          <span className="hdr-cart-count">{count}</span>
          <CartIcon />
          <span className="hdr-cart-label">Cart</span>
        </Link>
      </div>

      <nav className="hdr-sub" aria-label="Departments">
        <button type="button" className="hdr-sub-all" onClick={() => setDrawerOpen(true)}>
          ☰ All
        </button>
        <Link to="/search?deals=1">Today's Deals</Link>
        <Link to="/info/help">Customer Service</Link>
        <Link to="/search?dept=electronics">Electronics</Link>
        <Link to="/search?dept=home">Home &amp; Kitchen</Link>
        <Link to="/search?dept=fashion">Fashion</Link>
        <Link to="/search?dept=beauty">Beauty</Link>
        <Link to="/search?dept=sports">Sports &amp; Auto</Link>
        <Link to="/wishlist">Registry</Link>
        <Link to="/orders" className="hdr-sub-orders">
          Orders ({orders.length})
        </Link>
        <Link to="/cart">Gift Cards</Link>
      </nav>

      <div className="hdr-mobile-search">
        <form onSubmit={submit} role="search">
          <input
            className="hdr-input"
            value={query}
            placeholder="Search Nexa"
            aria-label="Search Nexa"
            onChange={(event) => setQuery(event.target.value)}
          />
          <button type="submit" className="hdr-go" aria-label="Search">
            <SearchIcon />
          </button>
        </form>
      </div>

      {locOpen && (
        <div className="modal-backdrop" onClick={() => setLocOpen(false)}>
          <div className="modal" onClick={(event) => event.stopPropagation()} role="dialog" aria-modal="true">
            <h2>Choose your delivery location</h2>
            <p className="modal-sub">
              Delivery options and speeds may vary by location. Your selection stays on this device.
            </p>
            <form onSubmit={savePostcode} className="modal-form">
              <label htmlFor="zip">Postcode or ZIP</label>
              <input
                id="zip"
                value={zipDraft}
                onChange={(event) => setZipDraft(event.target.value)}
                autoFocus
                maxLength={10}
              />
              <div className="modal-actions">
                <button type="button" className="btn btn-ghost" onClick={() => setLocOpen(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Apply
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {drawerOpen && (
        <div className="drawer-backdrop" onClick={() => setDrawerOpen(false)}>
          <aside className="drawer" onClick={(event) => event.stopPropagation()}>
            <div className="drawer-head">
              <span>Hello, sign in</span>
              <button type="button" onClick={() => setDrawerOpen(false)} aria-label="Close menu">
                ✕
              </button>
            </div>
            <h3>Shop by Department</h3>
            {departments.map((dept) => (
              <div key={dept.key} className="drawer-group">
                <Link to={`/search?dept=${dept.key}`} onClick={() => setDrawerOpen(false)}>
                  {dept.label}
                </Link>
                <ul>
                  {dept.categories.slice(0, 5).map((slug) => {
                    const cat = categories.find((c) => c.slug === slug)
                    if (!cat) return null
                    return (
                      <li key={slug}>
                        <Link to={`/search?cat=${slug}`} onClick={() => setDrawerOpen(false)}>
                          {cat.label}
                        </Link>
                      </li>
                    )
                  })}
                </ul>
              </div>
            ))}
            <h3>Help &amp; Settings</h3>
            <ul className="drawer-flat">
              <li>
                <Link to="/orders" onClick={() => setDrawerOpen(false)}>
                  Your Orders
                </Link>
              </li>
              <li>
                <Link to="/wishlist" onClick={() => setDrawerOpen(false)}>
                  Your Lists
                </Link>
              </li>
              <li>
                <Link to="/cart" onClick={() => setDrawerOpen(false)}>
                  Your Cart
                </Link>
              </li>
            </ul>
          </aside>
        </div>
      )}
    </header>
  )
}
