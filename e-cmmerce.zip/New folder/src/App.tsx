import { useEffect } from 'react'
import { Route, Routes, useLocation } from 'react-router-dom'
import { ChatWidget } from './components/ChatWidget'
import { Footer } from './components/Footer'
import { Header } from './components/Header'
import { useStore } from './context/StoreContext'
import { CartPage } from './pages/Cart'
import { CheckoutPage } from './pages/Checkout'
import { HomePage } from './pages/Home'
import { InfoPage } from './pages/Info'
import { NotFoundPage } from './pages/NotFound'
import { OrdersPage } from './pages/Orders'
import { ProductPage } from './pages/Product'
import { SearchPage } from './pages/Search'
import { WishlistPage } from './pages/Wishlist'

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo({ top: 0 })
  }, [pathname])
  return null
}

function Toast() {
  const { toast } = useStore()
  if (!toast) return null
  return (
    <div className={`toast toast-${toast.tone}`} role="status" key={toast.id}>
      {toast.message}
    </div>
  )
}

export function App() {
  return (
    <div className="app">
      <ScrollToTop />
      <Header />
      <main className="main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/product/:id" element={<ProductPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/orders" element={<OrdersPage />} />
          <Route path="/wishlist" element={<WishlistPage />} />
          <Route path="/info/:slug" element={<InfoPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
      <ChatWidget />
      <Toast />
    </div>
  )
}
