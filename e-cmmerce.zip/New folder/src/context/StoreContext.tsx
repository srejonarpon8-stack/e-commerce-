import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import { products } from '../data/catalogue'
import { useLocalStorage } from '../lib/hooks'
import type { CartLine, Order, OrderLine, Product, ShippingAddress } from '../types'

const productById = new Map<number, Product>(products.map((p) => [p.id, p]))

export const findProduct = (id: number): Product | undefined => productById.get(id)

export interface CartItem {
  product: Product
  qty: number
  lineTotal: number
}

interface Toast {
  id: number
  message: string
  tone: 'success' | 'info'
}

interface StoreValue {
  cart: CartLine[]
  items: CartItem[]
  count: number
  subtotal: number
  addToCart: (id: number, qty?: number) => void
  setQty: (id: number, qty: number) => void
  removeFromCart: (id: number) => void
  clearCart: () => void
  wishlist: number[]
  toggleWishlist: (id: number) => void
  recentlyViewed: number[]
  markViewed: (id: number) => void
  orders: Order[]
  placeOrder: (address: ShippingAddress) => Order
  toast: Toast | null
  notify: (message: string, tone?: 'success' | 'info') => void
  postcode: string
  setPostcode: (value: string) => void
}

const StoreContext = createContext<StoreValue | null>(null)

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useLocalStorage<CartLine[]>('nexa.cart', [])
  const [wishlist, setWishlist] = useLocalStorage<number[]>('nexa.wishlist', [])
  const [recentlyViewed, setRecentlyViewed] = useLocalStorage<number[]>('nexa.recent', [])
  const [orders, setOrders] = useLocalStorage<Order[]>('nexa.orders', [])
  const [postcode, setPostcode] = useLocalStorage<string>('nexa.postcode', '10001')
  const [toast, setToast] = useState<Toast | null>(null)

  const notify = useCallback(
    (message: string, tone: 'success' | 'info' = 'success') => {
      if (!message) {
        setToast(null)
        return
      }
      const id = Date.now()
      setToast({ id, message, tone })
      window.setTimeout(() => {
        setToast((current) => (current?.id === id ? null : current))
      }, 2600)
    },
    [],
  )

  const addToCart = useCallback(
    (id: number, qty = 1) => {
      setCart((current) => {
        const existing = current.find((line) => line.id === id)
        if (existing) {
          return current.map((line) =>
            line.id === id ? { ...line, qty: Math.min(99, line.qty + qty) } : line,
          )
        }
        return [...current, { id, qty }]
      })
      const product = findProduct(id)
      notify(`Added to cart: ${product ? product.title : 'item'}`)
    },
    [setCart, notify],
  )

  const setQty = useCallback(
    (id: number, qty: number) => {
      setCart((current) =>
        qty <= 0
          ? current.filter((line) => line.id !== id)
          : current.map((line) => (line.id === id ? { ...line, qty: Math.min(99, qty) } : line)),
      )
    },
    [setCart],
  )

  const removeFromCart = useCallback(
    (id: number) => setCart((current) => current.filter((line) => line.id !== id)),
    [setCart],
  )

  const clearCart = useCallback(() => setCart([]), [setCart])

  const toggleWishlist = useCallback(
    (id: number) => {
      setWishlist((current) => {
        const exists = current.includes(id)
        notify(exists ? 'Removed from your list' : 'Saved to your list', 'info')
        return exists ? current.filter((x) => x !== id) : [...current, id]
      })
    },
    [setWishlist, notify],
  )

  const markViewed = useCallback(
    (id: number) => {
      setRecentlyViewed((current) => [id, ...current.filter((x) => x !== id)].slice(0, 12))
    },
    [setRecentlyViewed],
  )

  const items = useMemo<CartItem[]>(
    () =>
      cart.flatMap((line) => {
        const product = findProduct(line.id)
        if (!product) return []
        return [{ product, qty: line.qty, lineTotal: Number((product.price * line.qty).toFixed(2)) }]
      }),
    [cart],
  )

  const count = useMemo(() => cart.reduce((sum, line) => sum + line.qty, 0), [cart])
  const subtotal = useMemo(
    () => Number(items.reduce((sum, item) => sum + item.lineTotal, 0).toFixed(2)),
    [items],
  )

  const placeOrder = useCallback(
    (address: ShippingAddress): Order => {
      const lines: OrderLine[] = items.map((item) => ({
        id: item.product.id,
        title: item.product.title,
        price: item.product.price,
        qty: item.qty,
        image: item.product.images[0],
      }))
      const shipping = subtotal >= 35 ? 0 : 4.99
      const tax = Number((subtotal * 0.0825).toFixed(2))
      const total = Number((subtotal + shipping + tax).toFixed(2))
      const order: Order = {
        id: `NX-${Math.floor(100000 + Math.random() * 899999)}`,
        placedAt: new Date().toISOString(),
        lines,
        subtotal,
        shipping,
        tax,
        total,
        address,
        eta: new Date(Date.now() + 3 * 86_400_000).toISOString(),
      }
      setOrders((current) => [order, ...current])
      setCart([])
      return order
    },
    [items, subtotal, setOrders, setCart],
  )

  const value = useMemo<StoreValue>(
    () => ({
      cart,
      items,
      count,
      subtotal,
      addToCart,
      setQty,
      removeFromCart,
      clearCart,
      wishlist,
      toggleWishlist,
      recentlyViewed,
      markViewed,
      orders,
      placeOrder,
      toast,
      notify,
      postcode,
      setPostcode,
    }),
    [
      cart,
      items,
      count,
      subtotal,
      addToCart,
      setQty,
      removeFromCart,
      clearCart,
      wishlist,
      toggleWishlist,
      recentlyViewed,
      markViewed,
      orders,
      placeOrder,
      toast,
      notify,
      postcode,
      setPostcode,
    ],
  )

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useStore(): StoreValue {
  const value = useContext(StoreContext)
  if (!value) throw new Error('useStore must be used inside StoreProvider')
  return value
}
