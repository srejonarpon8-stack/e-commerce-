export interface Product {
  id: number
  slug: string
  title: string
  brand: string
  category: string
  categoryLabel: string
  department: string
  departmentLabel: string
  price: number
  listPrice: number | null
  rating: number
  ratingCount: number
  stock: number
  images: string[]
  description: string
  features: string[]
  specs: { label: string; value: string }[]
  prime: boolean
  bestseller: boolean
  sponsored: boolean
  soldBy: string
  shipsFrom: string
  deliveryDays: number
  createdAt: number
}

export interface Category {
  slug: string
  label: string
  department: string
  departmentLabel: string
  count: number
  image: string
}

export interface Department {
  key: string
  label: string
  blurb: string
  categories: string[]
}

export interface CartLine {
  id: number
  qty: number
}

export interface OrderLine {
  id: number
  title: string
  price: number
  qty: number
  image: string
}

export interface Order {
  id: string
  placedAt: string
  lines: OrderLine[]
  subtotal: number
  shipping: number
  tax: number
  total: number
  address: ShippingAddress
  eta: string
}

export interface ShippingAddress {
  name: string
  line1: string
  city: string
  postcode: string
  country: string
  email: string
}

export interface Review {
  id: string
  author: string
  rating: number
  title: string
  body: string
  date: string
  verified: boolean
  helpful: number
}

export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}
