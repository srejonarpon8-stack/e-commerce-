import type { Review } from '../types'

const AUTHORS = [
  'Maya R.',
  'Daniel O.',
  'Priya S.',
  'Tom H.',
  'Alex W.',
  'Ji-woo K.',
  'Sam T.',
  'Nadia B.',
  'Chris L.',
  'Fatima A.',
]

const HEADLINES_GOOD = [
  'Exactly what I needed',
  'Great value for the price',
  'Better than I expected',
  'Solid everyday pick',
  'Would buy again',
]

const HEADLINES_MIXED = [
  'Good, with a couple of quirks',
  'Decent for the money',
  'Does the job',
]

const BODIES_GOOD = [
  'Arrived two days earlier than the estimate and the packaging was intact. I have used it daily for three weeks with no issues at all.',
  'I compared this against two pricier options and honestly could not tell the difference in day-to-day use. Build quality feels a step above the price.',
  'Bought this as a gift and ended up ordering a second one for myself. Fit and finish are both better than the photos suggest.',
  'The little details are what sold me — it is easy to set up and everything you need is in the box. No surprises.',
]

const BODIES_MIXED = [
  'Works well for the price, though the instructions are thin and I had to work a couple of things out myself. Still happy with it overall.',
  'Does what it says. Not premium feeling, but at this price that seems fair. Shipping was quick.',
  'Mostly great, one minor annoyance that I got used to after a week. Would still recommend it to a friend.',
]

function hash(input: string): number {
  let h = 2166136261
  for (let i = 0; i < input.length; i += 1) {
    h ^= input.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

function makeRng(seed: number) {
  let s = seed || 1
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0
    return s / 4294967296
  }
}

const pick = <T,>(rng: () => number, list: T[]): T => list[Math.floor(rng() * list.length)]

export function buildReviews(productId: number, rating: number): Review[] {
  const rng = makeRng(hash(`reviews-${productId}`))
  const count = 4 + Math.floor(rng() * 3)
  const reviews: Review[] = []

  for (let i = 0; i < count; i += 1) {
    const good = rng() > 0.28
    const starRating = good
      ? Math.min(5, Math.max(4, Math.round(rating + (rng() > 0.5 ? 0 : 1))))
      : Math.max(1, Math.min(3, Math.round(rating - 1)))
    const daysAgo = 2 + Math.floor(rng() * 240)

    reviews.push({
      id: `r-${productId}-${i}`,
      author: pick(rng, AUTHORS),
      rating: starRating,
      title: good ? pick(rng, HEADLINES_GOOD) : pick(rng, HEADLINES_MIXED),
      body: good ? pick(rng, BODIES_GOOD) : pick(rng, BODIES_MIXED),
      date: new Date(Date.now() - daysAgo * 86_400_000).toISOString(),
      verified: rng() > 0.25,
      helpful: Math.floor(rng() * 180),
    })
  }

  return reviews.sort((a, b) => +new Date(b.date) - +new Date(a.date))
}
