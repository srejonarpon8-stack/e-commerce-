import { useCallback, useEffect, useRef, useState } from 'react'

export function useLocalStorage<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const stored = window.localStorage.getItem(key)
      return stored ? (JSON.parse(stored) as T) : initial
    } catch {
      return initial
    }
  })

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value))
    } catch {
      /* storage full or blocked — the app still works for this session */
    }
  }, [key, value])

  return [value, setValue] as const
}

export function useTimeout(ms: number) {
  const [active, setActive] = useState(false)
  const timer = useRef<number | null>(null)

  const trigger = useCallback(() => {
    setActive(true)
    if (timer.current) window.clearTimeout(timer.current)
    timer.current = window.setTimeout(() => setActive(false), ms)
  }, [ms])

  useEffect(() => () => {
    if (timer.current) window.clearTimeout(timer.current)
  }, [])

  return [active, trigger] as const
}
