export const currency = (value: number): string => {
  const parts = value.toFixed(2).split('.')
  return `$${parts[0]}.${parts[1]}`
}

export const currencyParts = (value: number): { dollars: string; cents: string } => {
  const [dollars, cents] = value.toFixed(2).split('.')
  return { dollars, cents }
}

export const compactNumber = (value: number): string =>
  value >= 1000 ? `${(value / 1000).toFixed(value >= 10000 ? 0 : 1)}K` : String(value)

export const ratingLabel = (rating: number): string => {
  if (rating >= 4.6) return 'Excellent'
  if (rating >= 4.2) return 'Very good'
  if (rating >= 3.6) return 'Good'
  if (rating >= 3) return 'Average'
  return 'Mixed'
}

const DAY_MS = 86_400_000

export const deliveryWindow = (days: number): string => {
  const start = new Date(Date.now() + days * DAY_MS)
  const end = new Date(Date.now() + (days + 2) * DAY_MS)
  const fmt = (d: Date) =>
    d.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })
  return `${fmt(start)} - ${fmt(end)}`
}

export const shortDate = (iso: string): string =>
  new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })

export const plural = (count: number, word: string): string =>
  `${count} ${word}${count === 1 ? '' : 's'}`
