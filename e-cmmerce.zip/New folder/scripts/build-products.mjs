import fs from 'node:fs'

const sources = ['tmpdata/p1.json', 'tmpdata/p2.json']
const raw = sources.flatMap((file) => JSON.parse(fs.readFileSync(file, 'utf8')).products)

const CATEGORY_LABELS = {
  beauty: 'Beauty',
  fragrances: 'Fragrances',
  furniture: 'Furniture',
  groceries: 'Groceries',
  'home-decoration': 'Home Décor',
  'kitchen-accessories': 'Kitchen & Dining',
  laptops: 'Laptops',
  'mens-shirts': "Men's Shirts",
  'mens-shoes': "Men's Shoes",
  'mens-watches': "Men's Watches",
  'mobile-accessories': 'Mobile Accessories',
  motorcycle: 'Motorcycles',
  'skin-care': 'Skincare',
  smartphones: 'Smartphones',
  'sports-accessories': 'Sports Accessories',
  sunglasses: 'Sunglasses',
  tablets: 'Tablets',
  tops: "Women's Tops",
  vehicle: 'Vehicles',
  'womens-bags': "Women's Bags",
  'womens-dresses': "Women's Dresses",
  'womens-jewellery': "Women's Jewellery",
  'womens-shoes': "Women's Shoes",
  'womens-watches': "Women's Watches",
}

const DEPARTMENTS = [
  {
    key: 'electronics',
    label: 'Electronics & Computers',
    blurb: 'Laptops, phones, tablets and accessories',
    cats: ['laptops', 'smartphones', 'tablets', 'mobile-accessories', 'sunglasses'],
  },
  {
    key: 'fashion',
    label: 'Clothing, Shoes & Jewellery',
    blurb: 'Everyday fits, watches and accessories',
    cats: [
      'mens-shirts',
      'mens-shoes',
      'mens-watches',
      'womens-dresses',
      'womens-shoes',
      'womens-bags',
      'womens-jewellery',
      'womens-watches',
      'tops',
    ],
  },
  {
    key: 'home',
    label: 'Home & Kitchen',
    blurb: 'Furniture, décor, cookware and pantry',
    cats: ['furniture', 'home-decoration', 'kitchen-accessories', 'groceries'],
  },
  {
    key: 'beauty',
    label: 'Beauty & Personal Care',
    blurb: 'Skincare, fragrance and everyday essentials',
    cats: ['beauty', 'fragrances', 'skin-care'],
  },
  {
    key: 'sports',
    label: 'Sports, Auto & Outdoors',
    blurb: 'Gear, vehicles and accessories',
    cats: ['sports-accessories', 'motorcycle', 'vehicle'],
  },
]

const categoryToDepartment = new Map()
for (const dept of DEPARTMENTS) {
  for (const cat of dept.cats) categoryToDepartment.set(cat, dept)
}

function hash(input) {
  let h = 2166136261
  for (let i = 0; i < input.length; i += 1) {
    h ^= input.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

function makeRng(seed) {
  let s = seed || 1
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0
    return s / 4294967296
  }
}

function slugify(value) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60)
}

const FEATURE_TEMPLATES = {
  electronics: [
    'Fast charging with an included USB-C cable',
    'Works with all major operating systems',
    'Rated for daily use with a 1-year limited warranty',
  ],
  fashion: [
    'True to size with a relaxed, comfortable fit',
    'Machine washable — holds shape after repeat washes',
    'Free returns within 30 days',
  ],
  home: [
    'Built from durable, easy-clean materials',
    'Compact footprint that fits small spaces',
    'Ships flat, assembles in under 15 minutes',
  ],
  beauty: [
    'Dermatologist tested and cruelty free',
    'Lightweight formula that absorbs quickly',
    'Suitable for sensitive skin',
  ],
  sports: [
    'Weather-resistant construction for outdoor use',
    'Lightweight design that packs down small',
    'Includes all mounting hardware',
  ],
}

const SELLERS = [
  'Nexa Retail',
  'Harbour Goods Co.',
  'Northline Supply',
  'Vantage Direct',
  'Bluefield Trading',
]
const SHIPPERS = ['Nexa Fulfilment', 'Northline Logistics', 'Metro Parcel']

const products = raw.map((item) => {
  const rng = makeRng(hash(item.title))
  const dept = categoryToDepartment.get(item.category)
  const price = Number(item.price.toFixed(2))
  const listPrice =
    item.discountPercentage && item.discountPercentage > 1
      ? Number((price / (1 - item.discountPercentage / 100)).toFixed(2))
      : null
  const rating = Math.min(5, Math.max(2.4, Number((item.rating || 4).toFixed(1))))
  const ratingCount = 40 + Math.floor(rng() * 4800)
  const sentences = item.description.split(/(?<=\.)\s+/).filter(Boolean)
  const features = [...sentences.slice(0, 2), ...(FEATURE_TEMPLATES[dept?.key || 'home'] || [])].slice(0, 5)

  return {
    id: item.id,
    slug: `${slugify(item.title)}-${item.id}`,
    title: item.title,
    brand: item.brand || 'Nexa Basics',
    category: item.category,
    categoryLabel: CATEGORY_LABELS[item.category] || item.category,
    department: dept?.key || 'home',
    departmentLabel: dept?.label || 'Home & Kitchen',
    price,
    listPrice: listPrice && listPrice > price ? listPrice : null,
    rating,
    ratingCount,
    stock: Math.max(1, Math.min(120, item.stock ?? 20)),
    images: item.images.slice(0, 4),
    description: item.description,
    features,
    specs: [
      { label: 'Brand', value: item.brand || 'Nexa Basics' },
      { label: 'Department', value: dept?.label || 'Home & Kitchen' },
      { label: 'Category', value: CATEGORY_LABELS[item.category] || item.category },
      { label: 'Item model number', value: `NX-${String(item.id).padStart(5, '0')}` },
      { label: 'Shipping weight', value: `${(0.2 + rng() * 3).toFixed(2)} kg` },
    ],
    prime: rng() > 0.25,
    bestseller: rng() > 0.78,
    sponsored: rng() > 0.9,
    soldBy: SELLERS[Math.floor(rng() * SELLERS.length)],
    shipsFrom: SHIPPERS[Math.floor(rng() * SHIPPERS.length)],
    deliveryDays: 1 + Math.floor(rng() * 4),
    createdAt: 0,
  }
})

products.forEach((product, index) => {
  product.createdAt = 1700000000 + index * 997
})

const categories = Object.entries(CATEGORY_LABELS)
  .map(([slug, label]) => {
    const items = products.filter((p) => p.category === slug)
    const dept = categoryToDepartment.get(slug)
    return {
      slug,
      label,
      department: dept?.key || 'home',
      departmentLabel: dept?.label || 'Home & Kitchen',
      count: items.length,
      image: items[0]?.images[0] || '',
    }
  })
  .filter((c) => c.count > 0)
  .sort((a, b) => a.label.localeCompare(b.label))

const departments = DEPARTMENTS.map((dept) => ({
  key: dept.key,
  label: dept.label,
  blurb: dept.blurb,
  categories: dept.cats.filter((c) => categories.some((x) => x.slug === c)),
}))

const header = `// Generated by scripts/build-products.mjs — do not edit by hand.
import type { Category, Department, Product } from '../types'

`

const body = `export const products: Product[] = ${JSON.stringify(products, null, 2)}

export const categories: Category[] = ${JSON.stringify(categories, null, 2)}

export const departments: Department[] = ${JSON.stringify(departments, null, 2)}
`

fs.mkdirSync('src/data', { recursive: true })
fs.writeFileSync('src/data/catalogue.ts', header + body)
console.log(`Wrote ${products.length} products across ${categories.length} categories.`)
